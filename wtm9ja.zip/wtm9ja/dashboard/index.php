<?php
include "../configs.php";
if (isset($_SESSION['coin'])) {
    $chk = $db->query('select * from users where unk = "' . htmlentities($_SESSION['coin']) . '"');
    if ($chk->rowCount() == 1) {
        $dat = $chk->fetchAll(PDO::FETCH_ASSOC)[0];
        $_SESSION['web'] = $dat['unk'];
        ?>

        <!doctype html>
        <html class="no-js" lang="zxx">
            <head>
                <meta charset="utf-8">
                <meta http-equiv="x-ua-compatible" content="ie=edge">
                <title>WTM9ja Chat Bot</title>
                <meta name="description" content="">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <link rel="manifest" href="site.webmanifest">
                <link rel="shortcut icon" type="image/x-icon" href="../assets/img/favicon.png">

                <!-- CSS here -->
                <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
                <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
                <link rel="stylesheet" href="../assets/css/slicknav.css">
                <link rel="stylesheet" href="../assets/css/flaticon.css">
                <link rel="stylesheet" href="../assets/css/animate.min.css">
                <link rel="stylesheet" href="../assets/css/magnific-popup.css">
                <link rel="stylesheet" href="../assets/css/fontawesome-all.min.css">
                <link rel="stylesheet" href="../assets/css/themify-icons.css">
                <link rel="stylesheet" href="../assets/css/slick.css">
                <link rel="stylesheet" href="../assets/css/nice-select.css">
                <link rel="stylesheet" href="../assets/css/style.css">
                <link rel="stylesheet" href="../css/notifications/Lobibox.min.css">
                <link rel="stylesheet" href="../css/notifications/notifications.css" >
                <link rel="stylesheet" href="../css/css.css" >
                <style>
                    .hidden {
                        display: none !important;
                    }

                </style>
                <!--<link rel="stylesheet" href="../css/font-awesome.css" >-->
            </head>
            <body>
                <!--? Preloader Start -->
                <div id="preloader-active">
                    <div class="preloader d-flex align-items-center justify-content-center">
                        <div class="preloader-inner position-relative">
                            <div class="preloader-circle"></div>
                            <div class="preloader-img pere-text">
                                <img src="../assets/img/favicon.png" alt=""  style="width: 60px; height: 60px; border-radius: 50%;">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Preloader Start -->
                <header>
                    <!-- Header Start -->
                    <div class="header-area" style="border-width: 0px;">
                        <div class="main-header ">
                            <div class="header-bottom  header-sticky" style="border-top-width: 0px;">
                                <div class="container">
                                    <div class="row align-items-center">
                                        <!-- Logo -->
                                        <div class="col-xl-2 col-lg-2">
                                            <div class="logo">
                                                <a href="#"><img src="../assets/img/favicon.png" alt=""  style="width: 60px; height: 60px; border-radius: 50%;"></a>
                                            </div>
                                        </div>
                                        <div class="col-xl-10 col-lg-10">
                                            <div class="menu-wrapper  d-flex align-items-center justify-content-end">
                                                <!-- Main-menu -->
                                                <div class="main-menu d-none d-lg-block">
                                                    <nav> 
                                                        <ul id="navigation">                                                                                          
                                                            <?php
                                                            if ($dat['role'] == "superadmin") {
                                                                $nlen = strlen($dat['fname']);
                                                                ?>
                                                                <li><a id="support-menu-bt" href="#" onclick="chats()" ><i class="fa fa-comments"></i> Conversations</a></li>
                                                                <?php
                                                            } else {
                                                                $nlen = strlen($dat['fname']);
                                                                ?>
                                                                <li><a id="support-menu-bt" href="#" onclick="chats()" ><i class="fa fa-comments"></i> Conversations</a></li>
                                                            <?php } ?>
                                                            <li title="<?php echo $dat['fname']; ?>"><a href="#"><i class="fa fa-user"></i> <?php
                                                                    if ($nlen <= 10) {
                                                                        echo $dat['fname'];
                                                                    } else {
                                                                        echo substr($dat['fname'], 0, 8) . "...";
                                                                    }
                                                                    ?></a>
                                                                <ul class="submenu">
                                                                    <li><a href="#" onclick="$('#pass-modal').modal('show');"><i class="fa fa-lock"></i>Password</a></li>
                                                                    <li><a href="../logout/"><i class="fa fa-lock-open"></i> Logout</a></li>
                                                                </ul>
                                                            </li>
                                                        </ul>
                                                    </nav>
                                                </div>
                                            </div>
                                        </div> 
                                        <!-- Mobile Menu -->
                                        <div class="col-12">
                                            <div class="mobile_menu d-block d-lg-none"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Header End -->
                </header>
                <main style="background: #fff; min-height: 100%;">

                    <div class="col-md-12" style="padding-top: 2%;">
                        <center>
                            <div id="main-tracker" class="testimonial-form text-center" style="background: rgba(0,0,0,0); width: 100%;">
                                <!--<h3>TRACKING</h3>-->
                                <center>
                                    <table style="width: 100%;">
                                        <tr>
                                            <td style="width: 70%; padding: 0px;">
                                                <input id="search-main" type="text" placeholder="Search user by name" style="margin: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;">
                                            </td>
                                            <td style="width: 30%; padding: 0px;">
                                                <button name="submit" onclick="main_search()" class="submit-btn" style="margin: 0px; font-weight: bold; border-radius: 0 10px 10px 0;"><i class="fa fa-search"></i> SEARCH</button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="2" style="padding-top: 50px;">
                                                <?php
                                                if(isset($_GET['search'])){
                                                    if($_GET['search'] != ""){
                                                        $s = htmlentities($_GET['search']);
                                                        $rows = $db->query('select * from users where (unk != "'.$dat['unk'].'" && (fname like "'.$s.'%" || lname like "'.$s.'%")) order by fname asc')->fetchAll(PDO::FETCH_ASSOC);
                                                    }else{
                                                        $rows = $db->query('select * from users where unk != "'.$dat['unk'].'" order by fname asc')->fetchAll(PDO::FETCH_ASSOC);
                                                    }
                                                }else{
                                                    $rows = $db->query('select * from users where unk != "'.$dat['unk'].'" order by fname asc')->fetchAll(PDO::FETCH_ASSOC);
                                                }
                    
                                                
                                                foreach($rows as $rw){ 
                                                    ?>
                                                <div onclick="msg('<?php echo $rw['unk']; ?>')" class="card" style="padding: 20px; cursor: pointer;">
                                                    <table style="width: 100%;">
                                                        <tr>
                                                            <td style="width: 20%;">
                                                                <img src="../img/avatar.png" style="width: 50px; height: 50px; border-radius: 50%;"/>
                                                            </td>
                                                            <td style="width: 70%;">
                                                                <span style="font-weight: bold; color: #067bba;"><?php echo $rw['fname']." ".$rw['lname']; ?></span>
                                                            </td>
                                                            <td style="width: 10%;">
                                                                <i class="fa fa-chevron-right" style="font-size: 200%; color: #067bba;"></i>
                                                            </td>
                                                            
                                                        </tr>
                                                    </table>
                                                </div>
                                                        <?php
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                    </table>
                                </center>
                            </div>
                            
                        </center>
                    </div>
                </main>


                <div id="chats-modal" class="modal fade" role="dialog" >
                    <div class="modal-dialog modal-md">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="Login" style="text-transform: uppercase;">CONVERSATIONS</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body" style="height: 100%; background: rgba(0,100,2,0); border-radius: 10px;">
                                <div class="col-lg-12 col-md-12" style="min-height: 500px;">
                                    <div id="put-chats" style="min-height: 300px; width: 100%;">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="chat-box-modal" class="svq-modal modal fade" role="dialog">
                    <div class="modal-dialog modal-md">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="Login" style="text-transform: uppercase;"></h4>
                                <button id="chat-md1" type="button" class="close" onclick="$('#chat-box-modal').modal('hide');
                                                cha = '';" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body" style="height: 100%; background: rgba(0,100,2,0); border-radius: 10px;">
                                <div id="chat-row">
                                    <div id="chat-md" class="col-md-12" style="min-height: 500px;">
                                        <div id="chat-box" style="height: 550px; width: 100%; margin-right: 0%; margin-left: 0%;">

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="chat-box-file-modal" class="modal fade"  role="dialog" >
                    <div class="modal-dialog modal-md">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title"  style="text-transform: uppercase;"></h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body" style="height: 100%; background: rgba(0,100,2,0); border-radius: 10px;">

                                <div class="col-lg-12 col-md-12">
                                    <div style="min-height: 500px;">

                                        <div style="min-height: 200px; width: 100%;">
                                            <span onclick="clear_chat_image()" id="chat-image-file-clear" class="btn btn-danger hidden" style="float: right;"><i class="fa fa-trash"></i></span>
                                            <br><br>
                                            <center>
                                                <img id="blah7" src="" style="width: 300px;" />
                                                <br>
                                                <span id="chat-image-file" class="fileContainer" style="overflow: hidden; position: absolute; right: 35%; bottom: 1%; cursor: pointer;  margin-top: 0%;">
                                                    <form id="form7" runat="server">
                                                        <span style="width: 100%;">
                                                            <center> 
                                                                <div>
                                                                    <span style="background: #067bba; width: 101%; height: 101%; cursor: pointer; padding: 44px 44px; color: #fff; font-weight: bold; text-transform: uppercase; font-family: 'Barlow',sans-serif;">Select Image</span>
                                                                </div>
                                                            </center>
                                                        </span>
                                                        <input id="upload7" type='file' name="file" accept="image/*" style="cursor: inherit; filter: alpha(opacity=0); height: 50px; width: 200px; opacity: 0; position: absolute; right: 0%; text-align: right; top: 0px;">
                                                    </form>
                                                </span> 
                                                <br>
                                                <textarea id="chat-caption" class="hidden" style="width: 100%; font-size: 70%; resize: none; height: 50px;" placeholder="Caption..."></textarea>
                                                <br><br>
                                                <span onclick="image_reply()" id="chat-image-send-bt" class="btn btn-success hidden" style="font-weight:">SEND <i class="fa fa-arrow-right" style="margin-left: 10px;"></i></span>
                                            </center> 
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

               

                <div class="modal fade" id="pass-modal" tabindex="-1" role="dialog" aria-labelledby="Sign Up" aria-hidden="true">
                    <div class="modal-dialog modal-md">

                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="" style="text-transform: uppercase;"><i class="fa fa-lock"></i> Change Password</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body">
                                <div id="">
                                    <form>
                                        <div class="form-group">
                                            <input type="password" class="form-control" id="current_pass" placeholder="Current Password">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control" id="new_pass" placeholder="New Password">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control" id="new_pass2" placeholder="Confirm NewPassword">
                                        </div>

                                    </form>
                                    <p class="text-center">
                                        <button onclick="change_pass()" id="transfer_bt" class="btn btn-template-main" style="min-width: 60px;"><i class="fa fa-lock"></i> Change</button>
                                    </p>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>



                <!-- JS here -->

                <script src="../assets/js/vendor/modernizr-3.5.0.min.js"></script>
                <!-- Jquery, Popper, Bootstrap -->
                <script src="../assets/js/vendor/jquery-1.12.4.min.js"></script>
                <script src="../js/notifications/Lobibox.js"></script>
                <script src="../js/notifications/notification-active.js"></script>
                <script src="../js/js.js"></script>
                
                <script src="../assets/js/popper.min.js"></script>
                <script src="../assets/js/bootstrap.min.js"></script>
                <!-- Jquery Mobile Menu -->
                <script src="../assets/js/jquery.slicknav.min.js"></script>

                <!-- Jquery Slick , Owl-Carousel Plugins -->
                <script src="../assets/js/owl.carousel.min.js"></script>
                <script src="../assets/js/slick.min.js"></script>
                <!-- One Page, Animated-HeadLin -->
                <script src="../assets/js/wow.min.js"></script>
                <script src="../assets/js/animated.headline.js"></script>
                <script src="../assets/js/jquery.magnific-popup.js"></script>

                <!-- Nice-select, sticky -->
                <script src="../assets/js/jquery.nice-select.min.js"></script>
                <script src="../assets/js/jquery.sticky.js"></script>

                <!-- contact js -->
                <script src="../assets/js/contact.js"></script>
                <script src="../assets/js/jquery.form.js"></script>
                <script src="../assets/js/jquery.validate.min.js"></script>
                <script src="../assets/js/mail-script.js"></script>
                <script src="../assets/js/jquery.ajaxchimp.min.js"></script>

                <!-- Jquery Plugins, main Jquery -->	
                <script src="../assets/js/plugins.js"></script>
                <script src="../assets/js/main.js"></script>
                <script>
                    function main_search(){
                        var s = $("#search-main").val();
                        if(s !== ""){
                            document.location.assign('./?search='+s);
                        }else{
                            document.location.assign('./');
                        }
                    }
                    <?php
                    if(isset($_GET['search'])){
                        if($_GET['search'] != ""){
                            ?>
                              $("#search-main").val('<?php echo htmlentities($_GET['search']); ?>');
                                <?php
                        }
                    }
                    ?>
                </script>
                
                <style>
                    @media (max-width: 480px) {
                        .modal-body {
                            padding: 2px;
                        } 
                        .col-md-12 {
                            padding: 0px;
                        }
                        .col-md-6{
                            padding: 0px;
                        }
                        .col-md-4{
                            padding: 0px;
                        }
                        .col-md-3{
                            padding: 0px;
                        }
                        .container-fluid{
                            padding: 0px;
                        }
                        #main-tracker {
                            width: 100%;
                        }
                    }
                </style>
                
            </body>
        </html>
        <?php
    } else {
        header('location: ../');
    }
} else {
    header('location: ../');
}
