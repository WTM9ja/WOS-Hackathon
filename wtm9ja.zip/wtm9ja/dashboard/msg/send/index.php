<?php

//msg/send
include '../../../configs.php';
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if (!IS_AJAX) {
    die('Restricted access');
}
$pos = strpos($_SERVER['HTTP_REFERER'], getenv('HTTP_HOST'));
if ($pos === false) {
    die('Restricted access');
}
if (isset($_SESSION['web'])) {
    $chk = $db->query('select id, fname from users where unk = "' . $_SESSION['web'] . '"');
    if ($chk->rowCount()) {
        if (isset($_POST['rcvr'], $_POST['mes']) && !empty($_POST['rcvr'])) {
            $rcvr = htmlentities($_POST['rcvr']);
            $mes = htmlentities($_POST['mes']);
            $ck = $db->query('select id, fname from users where unk = "' . $rcvr . '"');
            if ($ck->rowCount() == 1) {
                if(!isset($_SESSION['chats'])){
                    $_SESSION['chats'] = [];
                }
                $b4 = $db->query('select id from notifz where remark = "first" &&  ((sndr = "' . $_SESSION['web'] . '" && rcvr = "' . $rcvr . '") || (rcvr = "' . $_SESSION['web'] . '" && sndr = "' . $rcvr . '")) order by id asc limit 1')->rowCount();
                if($b4 == 0){
                    $rmk = "first";
                }else{
                    $rmk = "";
                }
                $dat = $ck->fetchAll(PDO::FETCH_ASSOC)[0];
                $r1 = mt_rand(10, 99);
                $r2 = time();
                $r3 = mt_rand(0, 25);
                $r4 = mt_rand(0, 9);
                $r5 = mt_rand(0, 25);
                $r6 = mt_rand(0, 25);
                $arr = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
                $reff = $r1 . $arr[$r6] . $r2 . $arr[$r3] . $r4 . $arr[$r5];
                $sub = "chat";
                $cont = $mes;
                $time = time();
                if (isset($_FILES['file'])) {
                    if (isset($_FILES['file']) && $_FILES['file']['name'] !== "" && $_FILES['file']['size'] !== 0 && $_FILES['file']['size'] <= 2000000) {
                        if (!preg_match("/([^\w\s\d\-_~,;:\[\]\(\).])|([\.]{2,})/", $_FILES['file']['name'])) {
                            if (in_array(strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION)), array("jpeg", "jpg", "png", "gif"))) {
                                $rn = mt_rand(1, 100);
                                $uploadir = "../../../im12ages784345/";
                                $_FILES['file']['name'] = "CHAT-" . $rn . time() . "." . pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
                                $filename = $_FILES['file']['name'];
                                $filePath = $uploadir . $filename;
                                move_uploaded_file($_FILES['file']['tmp_name'], $filePath);
                                $inz = $db->prepare('insert into notifz (id, ref, sndr, rcvr, subject, content, file, action, role, checked, del, remark, date) VALUES(:id, :ref, :sndr, :rcvr, :subject, :content, :file, :action, :role, :checked, :del, :remark, :date)');
                                $do = $inz->execute(array(":id" => "0", ":ref" => $reff, ":sndr" => htmlentities($_SESSION['web']), ":rcvr" => $rcvr, ":subject" => $sub, ":content" => $cont, ":file" => "../im12ages784345/" . $filename, ":action" => "", ":role" => "notif", ":checked" => "", ":del" => "", ":remark" => $rmk, ":date" => $time));
                                if ($do) {
//                                    array_push($_SESSION['chats'], ["ref" => $reff, "who" => $_SESSION['web'], "content" => $cont, "open" => "", "color" => "", "file" => "../im12ages784345/" . $filename, "time" => date("d/m/y H:ia", $time), "date" => $time]);
                                    echo "success";
                                } else {
                                    echo "Oops! An error occured while submiting chat.";
                                }
                            } else {
                                echo "Error! File format not supported.";
                            }
                        } else {
                            echo "Error! The name of your file contains disallowed characters.";
                        }
                    } else {
                        echo "Error! File is invalid or it's size is larger than 2MB.";
                    }
                } else {
                    if(!empty($_POST['mes'])){
                    $inz = $db->prepare('insert into notifz (id, ref, sndr, rcvr, subject, content, file, action, role, checked, del, remark, date) VALUES(:id, :ref, :sndr, :rcvr, :subject, :content, :file, :action, :role, :checked, :del, :remark, :date)');
                    $do = $inz->execute(array(":id" => "0", ":ref" => $reff, ":sndr" => htmlentities($_SESSION['web']), ":rcvr" => $rcvr, ":subject" => $sub, ":content" => $cont, ":file" => "", ":action" => "", ":role" => "notif", ":checked" => "", ":del" => "", ":remark" => $rmk, ":date" => $time));
                    if ($do) {
//                        array_push($_SESSION['chats'], ["ref" => $reff, "who" => $_SESSION['web'], "content" => $cont, "open" => "", "color" => "", "file" => "", "time" => date("d/m/y H:ia", $time), "date" => $time]);
                        echo "success";
                    } else {
                        echo "Oops! An error occured while submiting chat.";
                    }
                    }
                    
                }
            }
        }
    } else {
        echo "You are not logged in!";
    }
} else {
    echo "You are not logged in!";
}