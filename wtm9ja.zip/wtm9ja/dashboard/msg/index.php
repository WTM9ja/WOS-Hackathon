<?php
//msg
include '../../configs.php';
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if (!IS_AJAX) {
    die('Restricted access');
}
$pos = strpos($_SERVER['HTTP_REFERER'], getenv('HTTP_HOST'));
if ($pos === false) {
    die('Restricted access');
}
if (isset($_SESSION['web'])) {
    if (isset($_POST['who']) && !empty($_POST['who'])) {
        $who = htmlentities($_POST['who']);
        $ck = $db->query('select * from users where unk = "' . $who . '"');
        if ($ck->rowCount() == 1) {
            $dat = $ck->fetchAll(PDO::FETCH_ASSOC)[0];
            $_SESSION['chats'] = [];
            ?>
            <div style="width: 100%; font-weight: bolder; font-size: 120%;">
                <table style="border-width: 0px; width: 100%; padding: 0px; margin: 0px;">
                    <tr>
                        <td colspan="3">
                            <div class="card" style="border-width: 0px; width: 100% !important; padding: 5px; margin: 0px; color: #2F94CF;">
                                <img src="../<?php echo $dat['dp']; ?>" style="width: 50px; height: 50px; border-radius: 50%;" alt=" ">
                                <span style="font-size: 70%; font-weight: bold;">@<?php echo strtoupper($dat['fname']); ?></span>
                                <span id="last-seen" hidden style="font-size: 50%; float: right; font-style: italic; color: green; font-weight: bold; margin-top: 15px;"></span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-width: 0px; width: 100%; padding: 0px; margin: 0px;">
                            <div id="put-chat" style="width: 100%; height: 350px; overflow-y: auto; padding-bottom: 10px; padding-top: 10px; margin-bottom: 10px; padding-right: 5px; color: #fff;">
                                <?php
                                $rows = $db->query('select * from notifz where ((sndr = "' . $_SESSION['web'] . '" && rcvr = "' . $who . '") || (rcvr = "' . $_SESSION['web'] . '" && sndr = "' . $who . '")) order by id asc limit 100')->fetchAll(PDO::FETCH_ASSOC);
                                if (count($rows) > 0) {
                                    $i = 0;
                                    foreach ($rows as $rw) {
                                        if ($rw['sndr'] == $_SESSION['web']) {
                                            $op = explode("//", $rw['checked']);
                                            $open = "";
                                            $color = "";
                                            if($rw['file'] == ""){
                                                $file = "";
                                            }else{
                                                echo $rw['file'];
                                                $file = $rw['file'];
                                            }
                                            if (in_array($who, $op)) {
                                                $open = "-open";
                                                $color = "color: green;";
                                            }
                                            ?>
                                            <div id="chat<?php echo $i; ?>" style="width: 100%;">
                                                <div style="margin-left: 30%; min-height: 60px; width: 70%; border-radius: 20px; border-bottom-right-radius: 0px; background: #0A1E31; color: #fff; padding: 10px; margin-bottom: 10px;">
                                                    <?php if ($rw['file'] != "") { ?><img src="<?php echo $file; ?>" alt=" " style="width: 100%;" /><?php } ?>
                                                    <p style="font-size: 70%; margin-bottom: 5px; font-weight: bold; color: #fff;"><?php echo $rw['content']; ?></p>
                                                    <span class="timez" style="margin-left: 55%; font-size: 50%;">
                                                        <i id="opened-<?php echo $rw['ref']; ?>" class="fa fa-envelope<?php echo $open; ?>" style="<?php if ($open != "") {
                                echo "color: green; ";
                            } ?>margin-right: 10px;"> </i> <?php echo date("d/m/y H:ia", $rw['date']); ?> </span>
                                                </div>
                                            </div>

                                            <?php
                                            
                                            array_push($_SESSION['chats'], ["flag" => "", "ref" => $rw['ref'], "who" => $_SESSION['web'], "content" => $rw['content'], "open" => $open, "color" => $color, "file" => $file, "time" => date("d/m/y H:ia", $rw['date']), "date" => $rw['date']]);
                                        } else {
                                            ?>

                                            <div id="chat<?php echo $i; ?>"  style="width: 100%;">
                                                <div style="min-height: 60px; width: 70%; border-radius: 20px; border-top-left-radius: 0px; background: #2F94CF; padding: 10px; margin-bottom: 10px;">
                        <?php if ($rw['file'] != "") { ?><img src="<?php echo $file; ?>" alt=" " style="width: 100%;" /><?php } ?>
                                                    <p style="font-size: 70%; margin-bottom: 5px; font-weight: bold; color: #fff;"><?php echo $rw['content']; ?></p>
                                                    <span class="timez" style="margin-left: 65%; font-size: 50%;"><?php echo date("d/m/y H:ia", $rw['date']); ?></span>
                                                </div>
                                            </div>
                                            <?php
                                            if($rw['file'] == ""){
                                                $file = "";
                                            }else{
                                                $file = explode("../", $rw['file'])[1];
                                            }
                                            array_push($_SESSION['chats'], ["flag" => "", "ref" => $rw['ref'], "who" => "", "content" => $rw['content'], "open" => "", "color" => "", "file" => $file, "time" => date("d/m/y H:ia", $rw['date']), "date" => $rw['date']]);
                                        }
                                        $i++;
                                    }
                                    ?>
                                    <input id="chats-num" type="hidden" value="<?php echo $i; ?>" />
                                <?php } else {
                                    ?>
                                    <div class="alert alert-success" style="text-align: center;">No chat history, start a conversation.</div>
            <?php } ?>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="1" style="border-width: 0px; width: 80%; padding: 0px; margin: 0px;">
                            <textarea id="chat-mes" class="form-control" style="max-width: 100%; font-size: 90%; resize: none; height: 70px; margin-bottom: 10px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;" placeholder="Message"></textarea>
                        </td>
                        <td colspan="1" style="border-width: 0px; width: 20%; padding: 0px; margin: 0px;">
                            <div style="width: 100%; height: 80px; background: rgba(0,0,0,0); border-top-right-radius: 10px; border-bottom-right-radius: 10px; padding: 0px;">
                                <span onclick="$('#chat-box-file-modal').modal('show');
                                        clear_chat_image();" class="btn btn-default" style=" padding-bottom: 0px; padding-top: 5px; height: 35px; border-radius: 0px 10px 0px 0px; width: 100%; margin-bottom: 0px; margin-top: 0px; font-size: 120%; border-width: 0px;"><i class="fa fa-paperclip"></i></span>
                                <span onclick="reply('<?php echo $who; ?>')" class="btn btn-default" style="padding-bottom: 0px; padding-top: 5px; height: 35px; border-radius: 0px 0px 10px 0px; width: 100%; margin-bottom: 0px; margin-top: 0px; border-width: 0px;"><span style="font-weight: bold; margin-right: 10px;">SEND</span> <i class="fa fa-arrow-right"></i></span>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
            <?php
        }
    }
} else {
    echo "You are not logged in!";
}