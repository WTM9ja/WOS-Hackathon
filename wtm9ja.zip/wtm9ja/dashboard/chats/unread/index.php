<?php

//chats/unread
include '../../../configs.php';
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if (!IS_AJAX) {
    die('Restricted access');
}
$pos = strpos($_SERVER['HTTP_REFERER'], getenv('HTTP_HOST'));
if ($pos === false) {
    die('Restricted access');
}
if (isset($_SESSION['web'])) {
    $chk = $db->query('select id from notifz where rcvr = "' . $_SESSION['web'] . '" && sndr != "" && sndr != "hopeways" && checked not like "%'.$_SESSION['web'].'%"');
    echo $chk->rowCount();
} else {
    $resp = ["done" => FALSE, "data" => "You're not logged in."];
    echo json_encode($resp);
}

