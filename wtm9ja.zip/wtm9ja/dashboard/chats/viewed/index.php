<?php

//chats/viewed
include '../../../configs.php';
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if (!IS_AJAX) {
    die('Restricted access');
}
$pos = strpos($_SERVER['HTTP_REFERER'], getenv('HTTP_HOST'));
if ($pos === false) {
    die('Restricted access');
}
if (isset($_SESSION['web'])) {
    $chk = $db->query('select id from users where unk = "' . $_SESSION['web'] . '"');
    if ($chk->rowCount() == 1) {
        if (isset($_POST['ref']) && !empty($_POST['ref'])) {
//            if(!isset($_SESSION['chats'])){
            $_SESSION['chats'] = [];
//            }
            $ref = htmlentities($_POST['ref']);
//            messages sent by $ref that have not been displayed
            $rows = $db->query('select * from notifz where ((sndr = "' . $_SESSION['web'] . '" && rcvr = "' . $ref . '") || (rcvr = "' . $_SESSION['web'] . '" && sndr = "' . $ref . '")) order by id asc limit 100')->fetchAll(PDO::FETCH_ASSOC);
            $i = 0;
            foreach ($rows as $rw) {
                if($rw['file'] == ""){
                                                $file = "";
                                            }else{
                                                $file = $rw['file'];
                                            }
                if ($rw['sndr'] == $_SESSION['web']) {
                    $op = explode("//", $rw['checked']);
                    $open = "";
                    $color = "";
                    if (in_array($ref, $op)) {
                        $open = "-open";
                        $color = "color: green;";
                    }
                    array_push($_SESSION['chats'], ["flag" => "", "ref" => $rw['ref'], "who" => $_SESSION['web'], "content" => $rw['content'], "open" => $open, "color" => $color, "file" => $file, "time" => date("d/m/y H:ia", $rw['date']), "date" => $rw['date']]);
                } else {
                    array_push($_SESSION['chats'], ["flag" => "", "ref" => $rw['ref'], "who" => "", "content" => $rw['content'], "open" => "", "color" => "", "file" => $file, "time" => date("d/m/y H:ia", $rw['date']), "date" => $rw['date']]);
                }
                $i++;
            }
//            messages sent by $ref that I have not read
            $rws = $db->query('select checked, ref from notifz where sndr = "' . $ref . '" && rcvr like "%' . $_SESSION['web'] . '%" && checked not like "%' . $_SESSION['web'] . '%"')->fetchAll(PDO::FETCH_ASSOC);
//            messages sent by me that $ref have read
            $rwz = $db->query('select checked, ref from notifz where sndr = "' . $_SESSION['web'] . '" && rcvr like "%' . $ref . '%" && checked like "%' . $ref . '%" order by id desc limit 50')->fetchAll(PDO::FETCH_ASSOC);

            $read = [];
            foreach ($rwz as $rw) {
                array_push($read, $rw['ref']);
            }
            foreach ($rws as $rw) {
                $vws = explode("//", $rw['checked']);
                if (!in_array($_SESSION['web'], $vws)) {
                    
                    array_push($vws, $_SESSION['web']);
                    $vwd = implode("//", $vws);
                    $db->query('update notifz set checked = "' . $vwd . '" where ref = "' . $rw['ref'] . '"');
                }
            }

            function array_msort($array, $cols) {
                $colarr = array();
                foreach ($cols as $col => $order) {
                    $colarr[$col] = array();
                    foreach ($array as $k => $row) {
                        $colarr[$col]['_' . $k] = strtolower($row[$col]);
                    }
                }
                $eval = 'array_multisort(';
                foreach ($cols as $col => $order) {
                    $eval .= '$colarr[\'' . $col . '\'],' . $order . ',';
                }
                $eval = substr($eval, 0, -1) . ');';
                eval($eval);
                $ret = array();
                foreach ($colarr as $col => $arr) {
                    foreach ($arr as $k => $v) {
                        $k = substr($k, 1);
                        if (!isset($ret[$k])) {
                            $ret[$k] = $array[$k];
                            $ret[$k][$col] = $array[$k][$col];
                        }
                    }
                }
                return $ret;
            }

            $chz = array_msort($_SESSION['chats'], array('date' => SORT_ASC));
            $resp = ["done" => TRUE, "data" => $read, "chats" => $chz];
            echo json_encode($resp);
        } else {
            $resp = ["done" => FALSE, "data" => "Access denied!"];
            echo json_encode($resp);
        }
    } else {
        $resp = ["done" => FALSE, "data" => "Unrecognised user."];
        echo json_encode($resp);
    }
} else {
    $resp = ["done" => FALSE, "data" => "You're not logged in."];
    echo json_encode($resp);
}

