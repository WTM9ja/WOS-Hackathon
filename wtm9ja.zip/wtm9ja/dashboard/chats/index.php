<?php
//chats
include '../../configs.php';
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if (!IS_AJAX) {
    die('Restricted access');
}
$pos = strpos($_SERVER['HTTP_REFERER'], getenv('HTTP_HOST'));
if ($pos === false) {
    die('Restricted access');
}
if (isset($_SESSION['web'])) {
    $ck = $db->query('select id from users where unk = "' . $_SESSION['web'] . '"');
    if ($ck->rowCount() == 1) {
        $dat = $ck->fetchAll(PDO::FETCH_ASSOC)[0];
        $ft = $db->query('select sndr, rcvr from notifz where (remark = "first" && (sndr = "' . $_SESSION['web'] . '" || rcvr = "' . $_SESSION['web'] . '") && sndr != "hopeways" && rcvr != "") order by id desc limit 100')->fetchAll(PDO::FETCH_ASSOC);
        ?>
        <div style="width: 100%;">
            <?php
            if (count($ft) > 0) {
                $chats = [];
                foreach ($ft as $f) {
                    if (!in_array($f['sndr'], $chats) && $f['rcvr'] == $_SESSION['web']) {
                        $last = $db->query('select date from notifz where ((sndr = "' . $_SESSION['web'] . '" && rcvr = "' . $f['sndr'] . '") || (rcvr = "' . $_SESSION['web'] . '" && sndr = "' . $f['sndr'] . '")) order by id desc limit 1')->fetchAll(PDO::FETCH_ASSOC)[0];
                        array_push($chats, ["who" => $f['sndr'], "date" => $last['date']]);
                    } elseif (!in_array($f['rcvr'], $chats) && $f['sndr'] == $_SESSION['web']) {
                        $last = $db->query('select date from notifz where ((sndr = "' . $_SESSION['web'] . '" && rcvr = "' . $f['rcvr'] . '") || (rcvr = "' . $_SESSION['web'] . '" && sndr = "' . $f['rcvr'] . '")) order by id desc limit 1')->fetchAll(PDO::FETCH_ASSOC)[0];
                        array_push($chats, ["who" => $f['rcvr'], "date" => $last['date']]);
                    }
                }

                function array_msort($array, $cols) {
                    $colarr = array();
                    foreach ($cols as $col => $order) {
                        $colarr[$col] = array();
                        foreach ($array as $k => $row) {
                            $colarr[$col]['_' . $k] = strtolower($row[$col]);
                        }
                    }
                    $eval = 'array_multisort(';
                    foreach ($cols as $col => $order) {
                        $eval .= '$colarr[\'' . $col . '\'],' . $order . ',';
                    }
                    $eval = substr($eval, 0, -1) . ');';
                    eval($eval);
                    $ret = array();
                    foreach ($colarr as $col => $arr) {
                        foreach ($arr as $k => $v) {
                            $k = substr($k, 1);
                            if (!isset($ret[$k])) {
                                $ret[$k] = $array[$k];
                                $ret[$k][$col] = $array[$k][$col];
                            }
                        }
                    }
                    return $ret;
                }

                $rws = array_msort($chats, array('date' => SORT_DESC));
                foreach ($rws as $chat) {
                    $last = $db->query('select * from notifz where ((sndr = "' . $_SESSION['web'] . '" && rcvr = "' . $chat['who'] . '") || (rcvr = "' . $_SESSION['web'] . '" && sndr = "' . $chat['who'] . '")) order by id desc limit 1')->fetchAll(PDO::FETCH_ASSOC)[0];
                    $unread = $db->query('select id from notifz where (rcvr = "' . $_SESSION['web'] . '" && sndr = "' . $chat['who'] . '") && checked not like "%'.$_SESSION['web'].'%"')->rowCount();
                    $usr = $db->query('select dp, fname from users where unk = "' . $chat['who'] . '"')->fetchAll(PDO::FETCH_ASSOC)[0];
                    $last_r = explode("//", $last['checked']);
                    $open = "";
                    if(in_array($chat['who'], $last_r)){
                        $open = "-open";
                    }
                    ?>
                    <div class="col-md-12" style="padding: 0px;">
                        <div onclick="msg('<?php echo $chat['who']; ?>')" class="alert alert-success" style="background: #0A1E31; color: #fff; border-radius: 5px; padding: 5px; margin-bottom: 10px;">
                            <table style="width: 100%; margin: 0px;">
                                <tr>
                                    <td style="width: 20%; border-width: 0px; margin: 0px; padding: 0px;">
                                        <img src="../<?php echo $usr['dp']; ?>" alt=" " style="width: 60px; height: 60px; border-radius: 50%;" />
                                    </td>
                                    <td style="width: 80%; border-width: 0px; margin: 0px; padding: 0px;">
                                        <span style="font-size: 90%; font-weight: bold;">@<?php echo strtolower($usr['fname']); if($unread > 0){ ?><div style="float: right; margin-right: 10px; margin-top: 10px; background: red; padding: 2px; min-width: 15px; min-height: 15px; font-size: 50%; border-radius: 50%; display: inline; color: #fff; font-weight: bold; text-align: center;"><?php echo $unread; ?></div><?php } ?></span> 
                                        <br>
                                        <span style="font-size: 60%;"><?php if ($last['file'] != "") { ?><i class="fa fa-image"></i> <?php } $lnx = strlen($last['content']); ?><span><?php if ($lnx <= 30) {
                        echo $last['content'];
                    } else {
                        echo substr($last['content'], 0, 28) . "...";
                        }  ?></span> <?php if($last['sndr'] == $_SESSION['web']){ ?><i class="fa fa-envelope<?php echo $open; ?>" style="float: right; margin-right: 10px; margin-top: 10px;"></i> <?php } ?></span>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                <?php
            }
        } else {
            ?>

                <div class="alert alert-success" style="margin-top: 15%; text-align: center;">
                    YOU ARE YET TO HAVE ANY CONVERSATION WITH ANY USER.
                    <br><br><br>
                    <span class="btn btn-tertiary" onclick="cons();
                                        $('#chats-modal').modal('hide');">GO TO CONNECTIONS</span>
                </div>
        <?php }
        ?>
        </div>
        <?php
    }
} else {
    echo "You are not logged in!";
}