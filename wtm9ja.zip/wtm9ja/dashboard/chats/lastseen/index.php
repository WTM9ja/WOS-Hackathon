<?php

//chats/lastseen
include '../../../configs.php';
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if (!IS_AJAX) {
    die('Restricted access');
}
$pos = strpos($_SERVER['HTTP_REFERER'], getenv('HTTP_HOST'));
if ($pos === false) {
    die('Restricted access');
}
if (isset($_SESSION['web'])) {
    if (isset($_POST['who'])) {
        if (!empty($_POST['who'])) {
            $who = htmlentities($_POST['who']);
            $chk = $db->query('select active from users where unk = "' . $who . '"');
            if ($chk->rowCount() > 0) {
                $dz = $chk->fetchAll(PDO::FETCH_ASSOC)[0];
                if ($dz['active'] != "") {
                    $dif = time() - $dz['active'];
                    $tx = "";
                    if($dif <= 20){
                        $tx = "Online";
                    }else{
                        if($dif >20 && $dif <= 60){
                            $t = $dif." Seconds Ago";
                        }elseif($dif >60 && $dif <= 3600){
                            $t = round(($dif/60), 0)." Minutes Ago";
                        }elseif($dif >3600 && $dif <= 86400){
                            $t = round(($dif/3600), 0)." Hours Ago";
                        }elseif($dif > 86400){
                            $t = round(($dif/86400), 0)." Days Ago";
                        }
                        $tx = $t;
                    }
                    $resp = ["done" => TRUE, "data" => $tx];
                    echo json_encode($resp);
                } else {
                    $put = '<span style="color: red;">Inactive</span>';
                    $resp = ["done" => TRUE, "data" => $put];
                    echo json_encode($resp);
                }
            } else {
                $resp = ["done" => FALSE, "data" => ""];
                echo json_encode($resp);
            }
        } else {
            $resp = ["done" => FALSE, "data" => ""];
            echo json_encode($resp);
        }
    } else {
        $resp = ["done" => FALSE, "data" => ""];
        echo json_encode($resp);
    }
} else {
    $resp = ["done" => FALSE, "data" => "You're not logged in."];
    echo json_encode($resp);
}

