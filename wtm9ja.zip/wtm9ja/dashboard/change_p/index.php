<?php
//dashboard/change_p
include '../../configs.php';
        define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if (!IS_AJAX) {
    die('Restricted access');
}
$pos = strpos($_SERVER['HTTP_REFERER'], getenv('HTTP_HOST'));
if ($pos === false) {
    die('Restricted access');
}

if(isset($_SESSION['coin'])){
    $who = $db->query('select * from users where unk = "'.$_SESSION['coin'].'"');
    if($who->rowCount() == 1){
      $dat = $who->fetchAll(PDO::FETCH_ASSOC)[0];
      if(isset($_POST['cp'], $_POST['p1'], $_POST['p2'])){
         if(!empty($_POST['cp'] && $_POST['p1'] && $_POST['p2'])){
          $cp = sha1($_POST['cp']);
          $p1 = $_POST['p1'];
          $p2 = $_POST['p2'];
          if($p1 == $p2){
              $chk = $db->query('select id from users where unk = "'.$_SESSION['coin'].'" and password = "'.$cp.'"');
              if($chk->rowCount() == 1){
                  $do = $db->query('update users set plug = "'.$p1.'", password = "'.sha1($p1).'" where unk = "'.$_SESSION['coin'].'"');
                  if($do){
                      echo "Password successfully changed, you will be redirected in a moment to login again.";
                  }else{
                      echo "Oops! An error occured while trying to update your new password.";
                  }
              }else{
                  echo "Current password is incorrect.";
              }
          }else{
              echo "New passwords do not match!";
          }
          
         }else{
             echo "Oops! All fields are required.";
         }
      }
    }else{
        echo "Access denied!!!";
    }
    
}else{
    echo "Oops! You are not logged in.";
}