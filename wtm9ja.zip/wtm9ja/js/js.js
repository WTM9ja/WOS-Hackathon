var cha = "";
var cha_img = "";
var chats_num = 0;
var active_chat;
var lastseen;
var who_pays = "sender";
var tot = 0;
var xyz = "";
function readURL3(input) {
//    alert();
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $("#blah7")
                    .attr('src', e.target.result);
            cha_img = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
        $("#chat-caption").removeClass("hidden");
        $("#chat-image-send-bt").attr("onclick", "image_reply('" + cha + "')");
        $("#chat-image-send-bt").removeClass("hidden");
        $("#chat-image-file-clear").removeClass("hidden");
        $("#chat-image-file").addClass("hidden");
    }
}


function clear_chat_image() {
    $("#chat-caption").val("");
    $("#chat-caption").addClass("hidden");
    $("#chat-image-send-bt").attr("onclick", "");
    $("#chat-image-send-bt").addClass("hidden");
    $("#chat-image-file-clear").addClass("hidden");
    $("#chat-image-file").removeClass("hidden");
    $("#blah7").attr('src', "");
}

$('#upload7').on('change', function () {
    var tis = document.getElementById("upload7");
    readURL3(tis);
});

function urlify(text) {
    var urlRegex = /(https?:\/\/[^\s]+)/g;
    return text.replace(urlRegex, function (url) {
        return '<a href="' + url + '" target="_blank">' + url + '</a>';
    });
    // or alternatively
//   return text.replace(urlRegex, '<a href="$1">$1</a>')
}


function interval(func, wait, times) {
    var interv = function (w, t) {
        return function () {
            if (typeof t === "undefined" || t-- > 0) {
                setTimeout(interv, w);
                try {
                    func.call(null);
                }
                catch (e) {
                    t = 0;
                    throw e.toString();
                }
            }
        };
    }(wait, times);



    $.queue = {
        _timer: null,
        _queue: [],
        add: function (fn, context, time) {
            var setTimer = function (time) {
                $.queue._timer = setTimeout(function () {
                    time = $.queue.add();
                    if ($.queue._queue.length) {
                        setTimer(time);
                    }
                }, time || 2);
            }

            if (fn) {
                $.queue._queue.push([fn, context, time]);
                if ($.queue._queue.length === 1) {
                    setTimer(time);
                }
                return;
            }

            var next = $.queue._queue.shift();
            if (!next) {
                return 0;
            }
            next[0].call(next[1] || window);
            return next[2];
        },
        clear: function () {
            clearTimeout($.queue._timer);
            $.queue._queue = [];
        }
    };




    setTimeout(interv, wait);
}


function notiz() {
    $.post('notifz/unread/', {}, function (data) {
//        
        var cn = parseInt(data.trim());
        tot = parseInt(tot) + parseInt(cn);
        if (cn > 0) {
            $("#notifz-unread").removeClass("hidden");
            $("#notifz-unread").html(cn);
        } else if (cn <= 0) {
            $("#notifz-unread").addClass("hidden");
        }
    });

    $.post('chats/unread/', {}, function (data) {
//        
        var cn = parseInt(data.trim());
        tot = parseInt(tot) + parseInt(cn);
        if (cn > 0) {
            $("#chats-unread").removeClass("hidden");
            $("#chats-unread").html(cn);
        } else if (cn <= 0) {
            $("#chats-unread").addClass("hidden");
        }
    });
    if (parseInt(tot) > 0) {
        $("#all-unread").css({"color": "red"});
    } else if (parseInt(tot) <= 0) {
        $("#all-unread").removeAttr("style");
    }
    tot = 0;

}

//notiz();

//interval(function () {
////    notiz();
//}, 5000, 86400);



$('#chat-box-file-modal').on('hidden.bs.modal', function (e) {
    clear_chat_image();
});

$('#chat-box-modal').on('hidden.bs.modal', function (e) {
    clearInterval(window.active_chat);
    clearInterval(window.lastseen);
    cha = "";
    chats_num = 0;

});

function view_chats(a) {
    $.post('chats/viewed/', {ref: a}, function (data) {
//        console.log(data);
        var resp = JSON.parse(data);
        if (resp.done === true) {
            var x = 0;
            for (x in resp.data) {
                $("#opened-" + resp.data[x]).removeClass('fa-envelope');
                $("#opened-" + resp.data[x]).addClass('fa-envelope-open');
            }
            var tt = parseInt(resp.chats.length) - 1;
            chats_num = tt;
            var k = 0;
            var f = 0;
            var flags = ["disgrace you", "make your life misrable", "will kill you", "you are going to die", "you are stupid", "go kill yourself", "will embarass you"];
            for (k in resp.chats) {
                if (k <= tt) {
                    var put = "";
                    if ($("#chat" + String(k)).length === 0) {
//                    console.log($("#chat" + String(k)).length, chats_num, "not", k);
//                    does not exist
                        if (resp.chats[k].who !== "") {
                            if (resp.chats[k].file !== "") {
                                put = '<div id="chat' + k + '" style="width: 100%;"><div style="margin-left: 30%; min-height: 60px; width: 70%; border-radius: 20px; border-bottom-right-radius: 0px; background: #0A1E31; color: #fff; padding: 10px; margin-bottom: 10px;"><img onclick="imgz(\'' + resp.chats[k].file + '\')" src="' + resp.chats[k].file + '" alt=" " style="width: 100%;" /><p style="font-size: 70%; margin-bottom: 5px; font-weight: bold; color: #fff;"> ' + resp.chats[k].content + ' </p> <span style="margin-left: 50%; font-size: 50%;" class="timez"><i id="opened-resp.chats[k].ref" class="fa fa-envelope' + resp.chats[k].open + '" style="' + resp.chats[k].color + ' margin-right: 10px;"> </i> ' + resp.chats[k].time + '</span></div></div>';
                            } else {
                                put = '<div id="chat' + k + '" style="width: 100%;"><div style="margin-left: 30%; min-height: 60px; width: 70%; border-radius: 20px; border-bottom-right-radius: 0px; background: #0A1E31; color: #fff; padding: 10px; margin-bottom: 10px;"><p style="font-size: 70%; margin-bottom: 5px; font-weight: bold; color: #fff;"> ' + resp.chats[k].content + ' </p> <span style="margin-left: 50%; font-size: 50%;" class="timez"><i id="opened-resp.chats[k].ref" class="fa fa-envelope' + resp.chats[k].open + '" style="' + resp.chats[k].color + ' margin-right: 10px;"> </i> ' + resp.chats[k].time + '</span></div></div>';

                            }
                            $("#put-chat").append(urlify(put));
                        } else {
                            var violated = false;
                            var bk = "#2F94CF";
                            var apn = '';
                            for(f in flags){
                              if(resp.chats[k].content.includes(flags[f])){
                                  violated = true;
                                  bk = "red";
                                   apn = '<div title="Block this user!" onclick="block(\''+a+'\')" style="height: 30px; width: 30px; border-radius: 50%; background: #fff; cursor: pointer; text-align: center;"><i class="fa fa-user-times" style="font-size: 80%; color: red;"></i></div>';
                              }
                            }
                            if (resp.chats[k].file !== "") {
                                put = '<div id="chat' + k + '"  style="width: 100%;"><div style="min-height: 60px; width: 70%; border-radius: 20px; border-top-left-radius: 0px; background: '+bk+'; padding: 10px; margin-bottom: 10px;">'+apn+'<img onclick="imgz(\'' + resp.chats[k].file + '\')" src="' + resp.chats[k].file + '" alt=" " style="width: 100%;" /><p style="font-size: 70%; margin-bottom: 5px; font-weight: bold; color: #fff;"> ' + resp.chats[k].content + ' </p> <span style="margin-left: 50%; font-size: 50%;" class="timez">' + resp.chats[k].time + '</span></div></div>';
                            } else {
                                put = '<div id="chat' + k + '"  style="width: 100%;"><div style="min-height: 60px; width: 70%; border-radius: 20px; border-top-left-radius: 0px; background: '+bk+'; padding: 10px; margin-bottom: 10px;">'+apn+'<p style="font-size: 70%; margin-bottom: 5px; font-weight: bold; color: #fff;"> ' + resp.chats[k].content + ' </p> <span style="margin-left: 50%; font-size: 50%;" class="timez">' + resp.chats[k].time + '</span></div></div>';
                            }
                            $("#put-chat").append(urlify(put));
                        }
                    } else {
//                    console.log($("#chat" + String(k)).length, chats_num, "exit", k);
//                    element exit
                        if (resp.chats[k].who !== "") {
                            if (resp.chats[k].file !== "") {
                                put = '<div id="chat' + k + '" style="margin-left: 30%; min-height: 60px; width: 70%; border-radius: 20px; border-bottom-right-radius: 0px; background: #0A1E31; color: #fff; padding: 10px; margin-bottom: 10px;"><img onclick="imgz(\'' + resp.chats[k].file + '\')" src="' + resp.chats[k].file + '" alt=" " style="width: 100%;" /><p style="font-size: 70%; margin-bottom: 5px; font-weight: bold; color: #fff;"> ' + resp.chats[k].content + ' </p> <span style="margin-left: 50%; font-size: 50%;" class="timez"><i id="opened-resp.chats[k].ref" class="fa fa-envelope' + resp.chats[k].open + '" style="' + resp.chats[k].color + ' margin-right: 10px;"> </i> ' + resp.chats[k].time + '</span></div>';
                            } else {
                                put = '<div id="chat' + k + '" style="margin-left: 30%; min-height: 60px; width: 70%; border-radius: 20px; border-bottom-right-radius: 0px; background: #0A1E31; color: #fff; padding: 10px; margin-bottom: 10px;"><p style="font-size: 70%; margin-bottom: 5px; font-weight: bold; color: #fff;"> ' + resp.chats[k].content + ' </p> <span style="margin-left: 50%; font-size: 50%;" class="timez"><i id="opened-resp.chats[k].ref" class="fa fa-envelope' + resp.chats[k].open + '" style="' + resp.chats[k].color + ' margin-right: 10px;"> </i> ' + resp.chats[k].time + '</span></div>';
                            }
                            $("#chat" + String(k)).html(urlify(put));
                        } else {
                            var violated = false;
                            var bk = "#2F94CF";
                            var apn = '';
                            for(f in flags){
                              if(resp.chats[k].content.includes(flags[f])){
                                  violated = true;
                                  bk = "red";
                                  apn = '<div title="Block this user!" onclick="block(\''+a+'\')" style="height: 30px; width: 30px; border-radius: 50%; background: #fff; cursor: pointer; text-align: center;"><i class="fa fa-user-times" style="font-size: 80%; color: red;"></i></div>';
                              }
                            }
                            if (resp.chats[k].file !== "") {
                                put = '<div id="chat' + k + '" style="min-height: 60px; width: 70%; border-radius: 20px; border-top-left-radius: 0px; background: '+bk+'; padding: 10px; margin-bottom: 10px;">'+apn+'<img onclick="imgz(\'' + resp.chats[k].file + '\')" src="' + resp.chats[k].file + '" alt=" " style="width: 100%;" /><p style="font-size: 70%; margin-bottom: 5px; font-weight: bold; color: #fff;"> ' + resp.chats[k].content + ' </p> <span style="margin-left: 50%; font-size: 50%;" class="timez">' + resp.chats[k].time + '</span></div>';
                            } else {
                                put = '<div id="chat' + k + '" style="min-height: 60px; width: 70%; border-radius: 20px; border-top-left-radius: 0px; background: '+bk+'; padding: 10px; margin-bottom: 10px;">'+apn+'<p style="font-size: 70%; margin-bottom: 5px; font-weight: bold; color: #fff;"> ' + resp.chats[k].content + ' </p> <span style="margin-left: 50%; font-size: 50%;" class="timez">' + resp.chats[k].time + '</span></div>';
                            }
                            $("#chat" + String(k)).html(urlify(put));

                        }

                    }

                }
            }
        }
    });
}


function last_seen(a) {
    if (a !== "") {
        $.post('chats/lastseen/', {who: a}, function (data) {
            var resp = JSON.parse(data);
            if (resp.done === true) {
                if (resp.data !== "Online") {
                    $("#last-seen").css({"color": ""});
                } else {
                    $("#last-seen").css({"color": "green"});
                }
                $("#last-seen").html(resp.data);
            }
        });
    }
}


function msg(a) {
    $("#chat-box-modal").modal('show');
    $("#chat-box").html('<center style="margin-top: 35%;"><div class="lds-facebook"><div></div><div></div><div></div></div></center>');
    $.post('msg/', {who: a}, function (data) {
        cha = a;
        $("#chat-box").html(urlify(data));
        setTimeout(function () {
            var objDiv = document.getElementById("put-chat");
            objDiv.scrollTop = objDiv.scrollHeight;
        }, 1000);
    });

    setTimeout(function () {
        chats_num = parseInt($("#chats-num").val());
    }, 1000);
    setTimeout(function () {
        view_chats(a);
        active_chat = interval(function () {
            view_chats(cha);
        }, 10000, 86400);
        lastseen = interval(function () {
            last_seen(cha);
        }, 10000, 86400);
    }, 3000);

}
function chats() {
    $("#chats-modal").modal('show');
    $("#put-chats").html('<center style="margin-top: 35%;"><div class="lds-facebook"><div></div><div></div><div></div></div></center>');
    $.post('chats/', {}, function (data) {
        $("#put-chats").html(data);
    });
}



function reply(a) {
    if (a !== "") {
        var mes = $("#chat-mes").val();
        if (mes !== "") {
            var d = new Date();
            var hr = d.getHours();
            var mn = d.getMinutes();
            var ampm = "am";
            if (hr > 12) {
                hr -= 12;
                ampm = "pm";
            }
            var tm = hr + ":" + mn + "" + ampm;
            chats_num = parseInt(chats_num) + 1;
            var put = '<div id="chat' + chats_num + '" style="width: 100%;"><div style="margin-left: 30%; min-height: 60px; width: 70%; border-radius: 20px; border-bottom-right-radius: 0px; background: #0A1E31; color: #fff; padding: 10px; margin-bottom: 10px;"><p style="font-size: 70%; margin-bottom: 5px; font-weight: bold;"> ' + mes + ' </p> <span class="timez" style="margin-left: 50%; font-size: 50%;"><i class="fa fa-envelope" style="margin-right: 10px;"></i>' + tm + '</span></div></div>';
            $("#put-chat").append(urlify(put));
            $("#chat-mes").val('');
            var objDiv = document.getElementById("put-chat");
            objDiv.scrollTop = objDiv.scrollHeight;
            $.post('msg/send/', {rcvr: a, mes: mes}, function (data) {
                if (data === "success") {

                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops!',
                        text: "Access denied!!!",
                        footer: '' + data + ''
                    });
                }
            });
        }
    }
}


function image_reply(a) {
    if (a !== "") {
        var mes = $("#chat-caption").val();
        if (mes !== "" || mes === "") {
            var d = new Date();
            var hr = d.getHours();
            var mn = d.getMinutes();
            var ampm = "am";
            if (hr > 12) {
                hr -= 12;
                ampm = "pm";
            }
            var tm = hr + ":" + mn + "" + ampm;
            var tm = hr + ":" + mn + "" + ampm;
            chats_num = parseInt(chats_num) + 1;
            var put = '<div id="chat' + chats_num + '" style="width: 100%;"><div style="margin-left: 30%; min-height: 60px; width: 70%; border-radius: 20px; border-bottom-right-radius: 0px; background: #0A1E31; color: #fff; padding: 10px; margin-bottom: 10px;"><p style="font-size: 70%; margin-bottom: 5px; font-weight: bold;"><img src="' + cha_img + '" alt=" " style="width: 100%;" /> ' + mes + ' </p> <span style="margin-left: 75%; font-size: 50%;"><i class="fa fa-envelope" style="margin-right: 10px;"></i>' + tm + '</span></div></div>';
            $("#put-chat").append(urlify(put));
            $("#chat-caption").val('');

            var form_data = new FormData();
            form_data.append('rcvr', a);
            form_data.append('mes', mes);
            var file = $("#upload7").prop('files')[0];
            form_data.append('file', file);
            $("#chat-image-send-bt").attr("onclick", "");
            $("#chat-box-file-modal").modal("hide");
            $.ajax({
                url: 'msg/send/',
                dataType: 'text',
                cache: false,
                contentType: false,
                processData: false,
                data: form_data,
                type: 'post',
                success: function (data) {
                    if (data === "success") {
                        var objDiv = document.getElementById("put-chat");
                        objDiv.scrollTop = objDiv.scrollHeight;
                    } else {
                        Lobibox.notify('error', {
                            delay: false,
                            showClass: 'rollIn',
                            hideClass: 'rollOut',
                            msg: data
                        });
                    }
                }
            });
        }
    }
}

function block(a){
    alert(a);
}


function support() {
    $("#support-modal").modal("show");
}

function start_chat() {
    var email = $("#support-email").val();
    if (email !== "") {
        $("#support-start-bt").html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
        $("#support-start-bt").css({"padding-top": "20px", "padding-bottom": "20px"});
        $.post('start_chat/', {email: email}, function (data) {
            var resp = JSON.parse(data);
            if (resp.done === true) {
                $("#support-start-bt").html('START CONVERSATION <i class="fa fa-chevron-right"></i>');
                $("#support-start-bt").css({"padding-top": "25px", "padding-bottom": "25px"});
                $("#support-modal").modal("hide");
                msg(resp.data);
                $("#support-float-bt").attr("onclick", "msg('" + resp.data + "')");
                $("#support-menu-bt").attr("onclick", "msg('" + resp.data + "')");
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: resp.msg
                });
            }
        });

    }
}


function payer(a) {
    who_pays = a;
}


function tracker(a) {
    var tid = $("#tracker-" + a).val();
    if (tid !== "") {
        $("#track-modal-head").html("STATUS INQUIRY FOR ID-" + tid);
        $("#track-modal-body").html('<center style="margin-top: 15%;"><div class="lds-facebook"><div></div><div></div><div></div></div></center>');
        $("#track-modal").modal("show");
        $.post('tracker/', {tid: tid}, function (data) {
            $("#track-modal-body").html(data);
        });
    }
}

function get_quote() {
    var sender_email = $("#quote-sender-email").val();
    var sender_mobile = $("#quote-sender-mobile").val();
    var receiver_name = $("#quote-receiver-name").val();
    var receiver_mobile = $("#quote-receiver-mobile").val();
    var item_type = $("#quote-item-type").val();
    var item_number = $("#quote-item-number").val();
    var item_weight = $("#quote-item-weight").val();
    var item_height = $("#quote-item-height").val();
    var state = $("#quote-state").val();
    var pickup_lga = $("#quote-pickup-lga").val();
    var delivery_lga = $("#quote-delivery-lga").val();
    var pickup_address = $("#quote-pickup-address").val();
    var delivery_address = $("#quote-delivery-address").val();
    var pickup_zone = $("#quote-pickup-zone").val();
    var delivery_zone = $("#quote-delivery-zone").val();
    var more_details = $("#quote-more-details").val();
    var chkmail = sender_email.split("@");
    var chkmail2 = sender_email.split(".");
    if (chkmail.length === 2 && chkmail2.length >= 2) {
        if (parseInt(sender_mobile) > 0 && sender_mobile.length >= 9) {
            if (receiver_name.length > 2) {
                if (parseInt(receiver_mobile) > 0 && receiver_mobile.length >= 9) {
                    if (item_type !== "") {
                        if (parseInt(item_number) >= 1) {
                            if (state !== "") {
                                if (pickup_lga !== "") {
                                    if (delivery_lga !== "") {
                                        if (pickup_address !== "") {
                                            if (delivery_address !== "") {
                                                if (pickup_zone !== "") {
                                                    if (delivery_zone !== "") {
                                                        if (parseInt(item_weight) > 0) {
                                                            if (parseInt(item_height) > 0) {
                                                                if (who_pays !== "") {
                                                                    $("#quote-bt").html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
                                                                    $.post('quote/',
                                                                            {sender_email: sender_email, sender_mobile: sender_mobile, receiver_name: receiver_name, receiver_mobile: receiver_mobile, item_type: item_type, item_number: item_number, item_weight: item_weight, item_height: item_height, state: state, delivery_lga: delivery_lga, pickup_lga: pickup_lga, pickup_address: pickup_address, delivery_address: delivery_address, pickup_zone: pickup_zone, delivery_zone: delivery_zone, more_details: more_details, payer: who_pays},
                                                                    function (data) {
                                                                        $("#quote-bt").html('Process Quote <i class="fa fa-chevron-right" style="margin-left: 10px;"></i>');
                                                                        var resp = JSON.parse(data);
                                                                        if (resp.done === true) {
                                                                            $("#quote-sender-email").val("");
                                                                            $("#quote-sender-mobile").val("");
                                                                            $("#quote-receiver-name").val("");
                                                                            $("#quote-receiver-mobile").val("");
                                                                            $("#quote-item-type").val("");
                                                                            $("#quote-item-number").val("");
                                                                            $("#quote-item-weight").val("");
                                                                            $("#quote-item-height").val("");
                                                                            $("#quote-state").val("");
                                                                            $("#quote-pickup-lga").val("");
                                                                            $("#quote-delivery-lga").val("");
                                                                            $("#quote-pickup-address").val("");
                                                                            $("#quote-delivery-address").val("");
                                                                            $("#quote-pickup-zone").val("");
                                                                            $("#quote-delivery-zone").val("");
                                                                            $("#quote-more-details").val("");
                                                                            Lobibox.notify('success', {
                                                                                delay: false,
                                                                                showClass: 'rollIn',
                                                                                hideClass: 'rollOut',
                                                                                msg: resp.msg
                                                                            });
                                                                            $("#track-modal-head").html("STATUS INQUIRY FOR ID-" + resp.data);
                                                                            $("#track-modal-body").html('<center style="margin-top: 15%;"><div class="lds-facebook"><div></div><div></div><div></div></div></center>');
                                                                            $("#track-modal").modal("show");
                                                                            $.post('tracker/', {tid: resp.data}, function (data) {
                                                                                $("#track-modal-body").html(data);
                                                                            });
                                                                        } else {
                                                                            Lobibox.notify('error', {
                                                                                delay: false,
                                                                                showClass: 'rollIn',
                                                                                hideClass: 'rollOut',
                                                                                msg: resp.msg
                                                                            });
                                                                        }
                                                                    });

                                                                } else {
                                                                    Lobibox.notify('error', {
                                                                        delay: false,
                                                                        showClass: 'rollIn',
                                                                        hideClass: 'rollOut',
                                                                        msg: "Oops! Payer must be specified."
                                                                    });
                                                                }
                                                            } else {
                                                                Lobibox.notify('error', {
                                                                    delay: false,
                                                                    showClass: 'rollIn',
                                                                    hideClass: 'rollOut',
                                                                    msg: "Item height must be greater than 0cm"
                                                                });
                                                            }
                                                        } else {
                                                            Lobibox.notify('error', {
                                                                delay: false,
                                                                showClass: 'rollIn',
                                                                hideClass: 'rollOut',
                                                                msg: "Item weight must be greater than 0Kg"
                                                            });
                                                        }
                                                    } else {
                                                        Lobibox.notify('error', {
                                                            delay: false,
                                                            showClass: 'rollIn',
                                                            hideClass: 'rollOut',
                                                            msg: "Oops! Delivery zone is required."
                                                        });
                                                    }
                                                } else {
                                                    Lobibox.notify('error', {
                                                        delay: false,
                                                        showClass: 'rollIn',
                                                        hideClass: 'rollOut',
                                                        msg: "Oops! Pickup zone is required."
                                                    });
                                                }
                                            } else {
                                                Lobibox.notify('error', {
                                                    delay: false,
                                                    showClass: 'rollIn',
                                                    hideClass: 'rollOut',
                                                    msg: "Oops! Delivery address is required."
                                                });
                                            }
                                        } else {
                                            Lobibox.notify('error', {
                                                delay: false,
                                                showClass: 'rollIn',
                                                hideClass: 'rollOut',
                                                msg: "Oops! Pickup address is required."
                                            });
                                        }
                                    } else {
                                        Lobibox.notify('error', {
                                            delay: false,
                                            showClass: 'rollIn',
                                            hideClass: 'rollOut',
                                            msg: "Oops! Delivery LGA is required."
                                        });
                                    }
                                } else {
                                    Lobibox.notify('error', {
                                        delay: false,
                                        showClass: 'rollIn',
                                        hideClass: 'rollOut',
                                        msg: "Oops! Pickup LGA is required."
                                    });
                                }
                            } else {
                                Lobibox.notify('error', {
                                    delay: false,
                                    showClass: 'rollIn',
                                    hideClass: 'rollOut',
                                    msg: "Oops! State is required."
                                });
                            }
                        } else {
                            Lobibox.notify('error', {
                                delay: false,
                                showClass: 'rollIn',
                                hideClass: 'rollOut',
                                msg: "Item number can't be less than 1"
                            });
                        }
                    } else {
                        Lobibox.notify('error', {
                            delay: false,
                            showClass: 'rollIn',
                            hideClass: 'rollOut',
                            msg: "Oops! Item type is required."
                        });
                    }
                } else {
                    Lobibox.notify('error', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: "Oops! Invalid mobile number!"
                    });
                }
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: "Oops! Receiver's name can't be lesser than 3 characters."
                });
            }
        } else {
            Lobibox.notify('error', {
                delay: false,
                showClass: 'rollIn',
                hideClass: 'rollOut',
                msg: "Oops! Invalid mobile number!"
            });
        }
    } else {
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: "Oops! Invalid email address."
        });
    }


}




function cop(a) {
    var copyText = document.getElementById(a);
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    document.execCommand("copy");
    Lobibox.notify('info', {
        delay: false,
        showClass: 'rollIn',
        hideClass: 'rollOut',
        msg: "Copied!"
    });
}

function proceed_pay(a, b, c, d, e) {
    $("#tracker-pay-bt-" + a).html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
    $("#tracker-pay-bt-" + a).css({"padding-top": "7px", "padding-bottom": "7px"});
    $.post('pay/', {ref: a, amt: b, who: c, e: e}, function (data) {
//            console.log(data);
        $('#tracker-pay-bt-' + a).removeClass('disabled');
        $('#tracker-pay-bt-' + a).attr('onclick', "quote_pay('" + a + "', '" + b + "', '" + c + "', '" + d + "', '" + e + "')");
        $('#tracker-pay-bt2-' + a).removeClass('disabled');
        $('#tracker-pay-bt2-' + a).attr('onclick', "quote_pay('" + a + "', '" + b + "', '" + c + "', '" + d + "', '" + e + "')");
        $("#tracker-pay-bt-" + a).html('PAY ₦' + d);
        $("#tracker-pay-bt-" + a).css({"padding-top": "20px", "padding-bottom": "20px"});
        var resp = JSON.parse(data);
        if (resp.done === true) {
            if (e === "") {
                ravepay(resp.ref, resp.amt, c);
            } else {
                Lobibox.notify('success', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: resp.mes
                });
                setTimeout(function () {
                    document.location.reload();
                }, 3000);
            }
        } else {
            Lobibox.notify('error', {
                delay: false,
                showClass: 'rollIn',
                hideClass: 'rollOut',
                msg: resp.mes
            });
        }
    });

}

function wallet_pay(a, b, c, d, e) {
    $("#tracker-pay-bt-" + a).html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
    $("#tracker-pay-bt-" + a).css({"padding-top": "7px", "padding-bottom": "7px"});
    $.post('walletpay/', {ref: a, amt: b, who: c, e: e}, function (data) {
//            console.log(data);
        $('#tracker-pay-bt-' + a).removeClass('disabled');
        $('#tracker-pay-bt-' + a).attr('onclick', "quote_pay('" + a + "', '" + b + "', '" + c + "', '" + d + "', '" + e + "')");
        $('#tracker-pay-bt2-' + a).removeClass('disabled');
        $('#tracker-pay-bt2-' + a).attr('onclick', "quote_pay('" + a + "', '" + b + "', '" + c + "', '" + d + "', '" + e + "')");
        $("#tracker-pay-bt-" + a).html('PAY ₦' + d);
        $("#tracker-pay-bt-" + a).css({"padding-top": "20px", "padding-bottom": "20px"});
        var resp = JSON.parse(data);
        if (resp.done === true) {
            Lobibox.notify('success', {
                delay: false,
                showClass: 'rollIn',
                hideClass: 'rollOut',
                msg: resp.mes
            });
            setTimeout(function () {
                document.location.reload();
            }, 3000);

        } else {
            Lobibox.notify('error', {
                delay: false,
                showClass: 'rollIn',
                hideClass: 'rollOut',
                msg: resp.mes
            });
        }
    });

}

function quote_pay(a, b, c, d, e) {
    if (a !== "" && parseInt(b) > 0 && c !== "") {
        if (xyz === "") {
            proceed_pay(a, b, c, d, e);
        } else {
            $("#proceed-pay-modal").modal('show');
            $("#pay-with-card").attr("onclick", "$('#proceed-pay-modal').modal('hide'); proceed_pay('" + a + "', '" + b + "', '" + c + "', '" + d + "', '" + e + "');");
            $("#pay-with-wallet").attr("onclick", "$('#proceed-pay-modal').modal('hide'); wallet_pay('" + a + "', '" + b + "', '" + c + "', '" + d + "', '" + e + "');");
        }
    } else {
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: "Invalid request!!!"
        });
    }
}


function confirm_pickup(a, b) {
    if (a !== "") {
        $("#confirm-pickup-bt-" + a + b).html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
        $.post('confirm/', {pickup: a}, function (data) {
            $("#confirm-pickup-bt-" + a + b).html('<i class="fa fa-gift"></i> CONFIRM PICKUP');
            if (data === "success") {
                $("#confirm-pickup-bt-" + a + b).attr('onclick', '');
                $("#confirm-pickup-bt-" + a + b).css({'background': '#28a745'});
                $("#confirm-pickup-bt-" + a + b).html('<i class="fa fa-check-circle"></i> PICKUP CONFIRMED');
                Lobibox.notify('success', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: "Pickup successfully confirmed!"
                });
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: data
                });

            }
        });
    }
}
function confirm_delivery(a, b) {
    if (a !== "") {
        $("#confirm-delivery-bt-" + a + b).html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
        $.post('confirm/', {delivery: a}, function (data) {
            $("#confirm-delivery-bt-" + a + b).html('<i class="fa fa-truck"></i> CONFIRM DELIVERY');
            if (data === "success") {
                $("#confirm-delivery-bt-" + a + b).attr('onclick', '');
                $("#confirm-delivery-bt-" + a + b).css({'background': '#28a745'});
                $("#confirm-delivery-bt-" + a + b).html('<i class="fa fa-check-circle"></i> DELIVERY CONFIRMED');
                Lobibox.notify('success', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: "Delivery successfully confirmed!"
                });
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: data
                });

            }
        });
    }
}

function show_pass(a) {
    if (a !== "") {
        if (a === "show") {
            $("#login-pass").attr("type", "text");
            $("#show-pass").attr("onclick", "show_pass('hide')");
            $("#show-pass").removeClass("fa-eye");
            $("#show-pass").addClass("fa-eye-slash");
        } else if (a === "hide") {
            $("#login-pass").attr("type", "password");
            $("#show-pass").attr("onclick", "show_pass('show')");
            $("#show-pass").removeClass("fa-eye-slash");
            $("#show-pass").addClass("fa-eye");

        }
    }
}

function login() {
    $("#login_bt").addClass('disabled');
    var email = $("#login-email").val();
    var pass = $("#login-pass").val();
    if (pass !== "" && email !== "") {
        $("#login-bt").html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
        $.post('login/', {email: email, pass: pass},
        function (data) {
            $("#login-bt").html('LOGIN <i class="fa fa-chevron-right"></i>');
            $("#login-bt").removeClass('disabled');
            if (data === "success") {
//               alert(data);
                window.location.assign('dashboard/');
            } else {
                if (data === "Oops! This user's account is not verified.") {
                    Lobibox.notify('error', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: "This user's account is not verified, kindly check your email for the activation code."
                    });
                    $('#reg_form').addClass('hidden');
                    $('#conf').removeClass('hidden');
                    $('#reg_head').addClass('hidden');
                    $('#conf_head').removeClass('hidden');
                    $("#login-modal").modal('hide');
                    $("#reg-modal").modal('show');
                    // resend();
                } else {
                    Lobibox.notify('error', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: data
                    });
                }
            }
        });
    } else {
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: "All fields are required!!!"
        });
    }

    setTimeout(function () {
        $("#resend_bt").removeClass('disabled');
    }, 20000);
}


function reg() {
    var fname = $("#reg_fname").val();
    var lname = $("#reg_lname").val();
    var email = $("#reg_email").val();
    var mobile = $("#reg_mobile").val();
    var pass = $("#reg_pass").val();
    var rfr = $("#reg_rfr").val();
    var conpass = $("#reg_conpass").val();
    if (fname !== "" && lname !== "" && email !== "" && mobile !== "" && pass !== "" && conpass !== "") {
        if (pass === conpass) {
            $("#reg_bt").html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
            $.post('reg/', {fname: fname, lname: lname, email: email, mobile: mobile, pass: pass, conpass: conpass, rfr: rfr},
            function (data) {
                console.log(data);
                var chk = data.search("success");
                $("#reg_bt").html('<i class="fa fa-plus"></i><i class="fa fa-user"></i> Submit');
                if (chk === 0) {
                    $('#reg_form').addClass('hidden');
                    $('#conf').removeClass('hidden');
                    $('#reg_head').addClass('hidden');
                    $('#conf_head').removeClass('hidden');
                    Lobibox.notify('success', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: "Successfully signed up, an activation code was sent to your email."
                    });
                    $("#reg_fname").val('');
                    $("#reg_lname").val('');
                    $("#reg_email").val('');
                    $("#reg_mobile").val('');
                    $("#reg_pass").val('');
                    $("#reg_conpass").val('');
                } else {
                    Lobibox.notify('error', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: data
                    });
                }
            });
        } else {
            Lobibox.notify('error', {
                delay: false,
                showClass: 'rollIn',
                hideClass: 'rollOut',
                msg: "Passwords do not match!"
            });
        }
    } else {
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: "Oops! All fields are required."
        });
    }
}


function confm() {
    var code = $("#conf_code").val();
    if (code !== "") {
        var lnt = code.length;
        if (lnt === 5) {
            $("#conf_bt").html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
            $.post('reg/', {conf: code},
            function (data) {
                $("#conf_bt").html('<i class="fa fa-check"></i> Confirm');
                if (data === "Account successfully activated.") {
                    Lobibox.notify('success', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: data
                    });
                    $("#conf_code").val('');
                    $("#reg-modal").modal('hide');
                    $('#reg_form').removeClass('hidden');
                    $('#conf').addClass('hidden');
                    $('#reg_head').removeClass('hidden');
                    $('#conf_head').addClass('hidden');
                    $("#login-modal").modal('show');
                } else {
                    Lobibox.notify('error', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: data
                    });
                }
            });
        } else {
            Lobibox.notify('error', {
                delay: false,
                showClass: 'rollIn',
                hideClass: 'rollOut',
                msg: "Invalid activation code!"
            });
        }
    } else {
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: "A valid activation code is required."
        });
    }

}


function resend() {
    $("#resend_bt").addClass('disabled');
    $("#resend_bt").html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
    $.post('reg/', {resend: ''},
    function (data) {
        $("#resend_bt").html('<strong>Resend code</strong>');
        Lobibox.notify('info', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: data
        });
    });
    setTimeout(function () {
        $("#resend_bt").removeClass('disabled');
    }, 20000);
}


function wallet() {
    $("#wallet-modal").modal('show');
    $("#balance-div").html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
//    fetch balance and update on UI
    $.post('bal/', {}, function (data) {
        var bal = data;
        $("#balance-div").html("₦" + bal + " NGN");
    });
}

function fund_wallet() {
    var amt = $("#wallet-amount").val();
    if (amt !== "" && parseInt(amt) >= 1000) {
        $("#wallet-bt").html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
        $.post('fund/', {amt: amt}, function (data) {
//            console.log(data);
            var resp = JSON.parse(data);
            $("#wallet-bt").html('₦</span><sup><i class="fa fa-plus" style="font-size: 80%; color: #fff;"></i></sup>');
            if (resp.done === true) {
                $("#wallet-amount").val('');
                ravewallet(resp.ref, resp.amt, resp.who);
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: resp.mes
                });
            }
        });
    } else {
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: "Amount can't be less than 1,000 NGN"
        });
    }
}


function update_user(a) {
    var fname = $("#fname" + a).val();
    var lname = $("#lname" + a).val();
    var email = $("#email" + a).val();
    var mobile = $("#mobile" + a).val();
    var plug = $("#plug" + a).val();
    var verif = $("#verified" + a).val();
    var balance = $("#balance" + a).val();
    if (fname !== "" && lname !== "" && email !== "" && mobile !== "" && plug !== "" && verif !== "" && balance !== "") {
        $("#update-bt" + a).html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
        $.post('edit/', {unk: a, fname: fname, lname: lname, email: email, mobile: mobile, plug: plug, verif: verif, balance: balance}, function (data) {
            $("#update-bt" + a).html('<i class="fa fa-check"></i> Update');
            if (data === "success") {

                Lobibox.notify('success', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: "Details succesffully updated!!!"
                });
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: data
                });
            }
        });
    } else {
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: "Oops! All fields are required!!!"
        });
    }
}


function change_pass() {
    var cp = $("#current_pass").val();
    var p1 = $("#new_pass").val();
    var p2 = $("#new_pass2").val();
    if (cp !== "" && p1 !== "" && p2 !== "") {
        if (p1 === p2) {
            $.post('change_p/', {cp: cp, p1: p1, p2: p2},
            function (data) {
                if (data === "Password successfully changed, you will be redirected in a moment to login again.") {
                    Lobibox.notify('success', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: data
                    });
                    setTimeout(function () {
                        document.location.assign('../');
                    }, 4000);
                } else {
                    Lobibox.notify('error', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: data
                    });
                }
            });
        } else {
            Lobibox.notify('error', {
                delay: false,
                showClass: 'rollIn',
                hideClass: 'rollOut',
                msg: "New passwords do not match!"
            });
        }
    } else {
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: "Oops! All fields are required."
        });
    }
}



function change_state() {
    var st = $("#quote-state").val();
    $("#quote-pickup-zone").remove();
    $("#quote-delivery-zone").remove();
    $("#quote-pickup-zone-cont").removeClass("hidden");
    $("#quote-delivery-zone-cont").removeClass("hidden");
    if (st !== "") {
        $.post('state/', {state: st}, function (data) {
//            console.log(data);
            var resp = JSON.parse(data);
            var p = 0;
            var d = 0;
            var pick = "";
            var dil = "";
            for (p in resp.data.pickup) {
                pick = pick + '<option value="' + resp.data.pickup[p].value + '">' + resp.data.pickup[p].name + '</option>';
            }
            $("#quote-pickup-zone-cont").append('<select id="quote-pickup-zone" name="select" class="form-control" style="height: 40px;" ><option value="">Pickup Zone</option>' + pick + '</select>');
            for (d in resp.data.delivery) {
                dil = dil + '<option value="' + resp.data.delivery[d].value + '">' + resp.data.delivery[d].name + '</option>';
            }
            $("#quote-delivery-zone-cont").append('<select id="quote-delivery-zone" name="select" class="form-control" style="height: 40px;" ><option value="">Delivery Zone</option>' + dil + '</select>');


        });
    } else {
        $("#quote-pickup-zone-cont").addClass("hidden");
        $("#quote-delivery-zone-cont").addClass("hidden");
        $("#quote-pickup-zone-cont").append('<select id="quote-pickup-zone" name="select" class="form-control" style="height: 40px;" ><option value="">Pickup Zone</option></select>');
        $("#quote-delivery-zone-cont").append('<select id="quote-delivery-zone" name="select" class="form-control" style="height: 40px;" ><option value="">Delivery Zone</option></select>');
    }
}

function with_approve(a) {
    if (a !== "") {
        $("#with-approve-bt" + a).html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
        $.post('approve_with/', {ref: a}, function (data) {
            if (data === "done") {
                $("#with-approve-bt" + a).html('Approved');
                $("#with-cancel-bt" + a).remove();
                $("#with-approve-bt" + a).css({"color": "green", "text-transform": "uppercase"});
                Lobibox.notify('success', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: "Withdrawal request successfully approved"
                });
            } else {
                $("#with-approve-bt" + a).html('<i class="fa fa-check"></i> Approve');
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: data
                });
            }
        });
    }
}


function with_cancel(a) {
    if (a !== "") {
        $("#with-cancel-bt" + a).html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
        $.post('approve_with/', {ref: a, action: 'C'}, function (data) {
            $("#with-cancel-bt" + a).html('<i class="fa fa-trash-o"></i> CANCEL');
            if (data === "done") {
                Lobibox.notify('success', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: "Withdrawal request successfully cancelled"
                });
                setTimeout(function () {
                    document.location.reload();
                }, 3000);
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: data
                });
            }
        });
    }
}


function leader(a) {
    if (a !== "") {
        var email = $("#" + a + "-email").val();
        var mobile = $("#" + a + "-mobile").html();
        if (email !== "") {
            var u = email.split("@");
            if (u.length === 2 && u[0] !== "") {
                $("#" + a + "-bt").html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
                $.post('leaders/', {state: a, leader: email}, function (data) {
                    $("#" + a + "-bt").html('SAVE <i class="fa fa-check"></i>');
                    if (data === "Leader successfully updated.") {
                        Lobibox.notify('success', {
                            delay: false,
                            showClass: 'rollIn',
                            hideClass: 'rollOut',
                            msg: data
                        });
                        setTimeout(function () {
                            window.location.reload();
                        }, 2000);
                    } else {
                        Lobibox.notify('error', {
                            delay: false,
                            showClass: 'rollIn',
                            hideClass: 'rollOut',
                            msg: data
                        });
                    }
                });
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: "Leader's email address is invalid, email must contain \"@\""
                });
            }
        } else if (mobile !== "") {
            $("#" + a + "-bt").html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');
            $.post('leaders/', {state: a, leader: email}, function (data) {
                $("#" + a + "-bt").html('SAVE <i class="fa fa-check"></i>');
                if (data === "Leader successfully updated.") {
                    Lobibox.notify('success', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: data
                    });
                    setTimeout(function () {
                        window.location.reload();
                    }, 2000);
                } else {
                    Lobibox.notify('error', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: data
                    });
                }
            });
        }
    } else {
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: "Invalid request!!!"
        });
    }
}



var transfer = false;
function switch_minus(a) {
    if (a === "withdraw") {
        $("#minus-" + a).css({"color": "#191919", "background": "#fff"});
        $("#minus-transfer").css({"color": "#fff", "background": "#191919"});
        $("#minus-receiver-cont").addClass("hidden");
        $("#widthd-dest-cont").removeClass("hidden");
        transfer = false;
    } else if (a === "transfer") {
        $("#minus-" + a).css({"color": "#191919", "background": "#fff"});
        $("#minus-withdraw").css({"color": "#fff", "background": "#191919"});
        $("#minus-receiver-cont").removeClass("hidden");
        $("#widthd-dest-cont").addClass("hidden");
        transfer = true;
    }
}



var wtd = "";
function withd(a) {
    var amt = $("#minus-money").val();
    var rcv = $("#minus-receiver").val();
    var dest = $("#widthd-dest").val();
    if (amt !== "") {
        if (parseInt(amt) >= 1000) {
            if ((transfer === true && rcv !== "") || transfer === false) {
                if (transfer === true || (transfer === false && dest !== "")) {
                    $("#withd-bt").html('<small style="font-size: 50%; font-weight: bolder;">Processing...</small>');
                    $.post('withdraw/', {who: a, amt: amt, rcv: rcv, dest: dest}, function (data) {
                        $("#withd-bt").html('<span style="font-size: 150%;">₦</span><sup><i class="fa fa-plus" style="font-size: 80%; color: #fff;"></i></sup>');
                        $("#minus-money").val('');
                        var sp = data.slice(0, 6);
                        if (sp === "An OTP") {
                            wtd = a;
                            document.getElementById('put-auth').innerHTML = '<div class="form-group"><table style="width: 100%;"><tr style="margin-top: 0px;"><td colspan="5" style="border-top: 0px solid #eee; text-align: center;"><span style="color: red; font-weight: bolder; text-transform: uppercase; font-family: monospace; font-size: 70%;">Enter the 5 digit PIN sent to your Email.</span><br><br><br></td></tr><tr style="margin-top: 0px;"><td style="border-top: 0px solid #eee; width: 20%; text-align: center; padding: 0px;"><input onkeyup="auth_edit(\'a\')" onfocus="auth_focus(\'a\')" id="auth_a" type="password" autocomplete="off" placeholder="A" style="width: 80%; height: 40px; text-align: center; color: rgba(0,5,37,1.0);" /></td><td style="border-top: 0px solid #eee; width: 20%; text-align: center; padding: 0px"><input onkeyup="auth_edit(\'u\')" onfocus="auth_focus(\'u\')" id="auth_u" type="password" autocomplete="off" placeholder="U" style="width: 80%; height: 40px; text-align: center; color: rgba(0,5,37,1.0);" /></td><td style="border-top: 0px solid #eee; width: 20%; text-align: center; padding: 0px;"><input onkeyup="auth_edit(\'t\')" onfocus="auth_focus(\'t\')" id="auth_t" type="password" autocomplete="off" placeholder="T" style="width: 80%; height: 40px; text-align: center; color: rgba(0,5,37,1.0);" /></td><td style="border-top: 0px solid #eee; width: 20%; text-align: center; padding: 0px;"><input onkeyup="auth_edit(\'h\')" onfocus="auth_focus(\'h\')" id="auth_h" type="password" autocomplete="off" placeholder="H" style="width: 80%; height: 40px; text-align: center; color: rgba(0,5,37,1.0);" /></td><td style="border-top: 0px solid #eee; width: 20%; text-align: center; padding: 0px;"><input onkeyup="auth_edit(\'s\')" onfocus="auth_focus(\'s\')" id="auth_s" type="password" autocomplete="off" placeholder="S" style="width: 80%; height: 40px; text-align: center; color: rgba(0,5,37,1.0);" /></td></tr><tr style="margin-top: 0px;"><td colspan="5" style="border-top: 0px solid #eee; text-align: center;"><center><span class="btn btn-default" onclick="auth_sub()" id="auth-bt" style="border: 2px solid #eee; background-color: #4682b4; color: #eee; font-weight: bold; padding: 5px; padding-left: 20px; padding-right: 20px; font-size: 120%; border-radius: 5px; text-align: right; margin-right: 20px; margin-top: 50px;"><i class="fa fa-lock" style="margin-right: 5px;"></i> SUBMIT</span></center></td></tr></table></div>';
                            $('#auth-modal').modal('show');
                            Lobibox.notify('success', {
                                delay: false,
                                showClass: 'rollIn',
                                hideClass: 'rollOut',
                                msg: data
                            });
                        } else {
                            Lobibox.notify('error', {
                                delay: false,
                                showClass: 'rollIn',
                                hideClass: 'rollOut',
                                msg: data
                            });
                        }
                    });
                } else {
                    Lobibox.notify('error', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: 'You have to select a payment destination!'
                    });

                }
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: 'You have to select a recipient!'
                });

            }
        } else {
            Lobibox.notify('error', {
                delay: false,
                showClass: 'rollIn',
                hideClass: 'rollOut',
                msg: 'Amount must be numeric and can\'t be less than ₦1000.00 NGN'
            });

        }
    }

}

function withd_set() {
    var bank = $("#withd-set-bank").val();
    var num = $("#withd-set-bank-num").val();
    var name = $("#withd-set-bank-name").val();
    var btc = $("#withd-set-btc").val();
    if ((bank !== "" && num !== "" && name !== "") || btc !== "") {
        $("#withd-set-bt").html('<div class="lds-ellipsis-small"><div></div><div></div><div></div><div></div></div>');
        $.post('withdraw/settings/', {bank: bank, num: num, name: name, btc: btc}, function (data) {
            $("#withd-set-bt").html('UPDATE DETAILS');
            if (data === "Withdrawal settings successfully updated.") {
                Lobibox.notify('success', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: '' + data + ''
                });
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: '' + data + ''
                });
            }
        });
    } else {

        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: 'All local bank detail\'s fields or BTC address are/is required!'
        });
    }
}


function fund(a) {
    $("#fund-modal").modal('show');
    $("#put-fund").html('<center style="margin-top: 10%; margin-bottom: 10%;"><div class="lds-facebook"><div></div><div></div><div></div></div></center>');
    $.post('funds/', {who: a}, function (data) {
        $("#put-fund").html(data);
    });
}


function auth_sub() {
    var tpa = $("#auth_a").val();
    var tpu = $("#auth_u").val();
    var tpt = $("#auth_t").val();
    var tph = $("#auth_h").val();
    var tps = $("#auth_s").val();
    if (tpa !== "" && parseInt(tpa) >= 0 && tpu !== "" && parseInt(tpu) >= 0 && tpt !== "" && parseInt(tpt) >= 0 && tph !== "" && parseInt(tph) >= 0 && tps !== "" && parseInt(tps) >= 0) {
        var pin = String(tpa) + String(tpu) + String(tpt) + String(tph) + String(tps);
        $("#auth-bt").html("Verifying...");
        $.post('auth/', {cid: pin}, function (data) {
            $("#auth-bt").html('<i class="fa fa-lock"></i> SUBMIT');
            if (data === "Request successfully sent, kindly ensure that your bank details are appropriately filled.") {
                Lobibox.notify('success', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: '' + data + ''
                });

                fund(wtd);
                wtd = "";
                $("#put-auth").html("");
                $("#auth-modal").modal('hide');
            } else {
                if (data === "Access denied!" || "Oops! An error occured while trying to process this request, try again.") {
                    $("#put-auth").html("");
                    $("#auth-modal").modal('hide');
                }
                $("#auth_a").val("");
                $("#auth_a").focus();
                $("#auth_u").val("");
                $("#auth_t").val("");
                $("#auth_h").val("");
                $("#auth_s").val("");
                if (data === "This autorization PIN has expired, and a new PIN has been sent to your email.") {
                    Lobibox.notify('info', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: '' + data + ''
                    });
                } else {
                    Lobibox.notify('error', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: '' + data + ''
                    });

                }
            }
        });
    } else {
        $("#auth_a").val("");
        $("#auth_a").focus();
        $("#auth_u").val("");
        $("#auth_t").val("");
        $("#auth_h").val("");
        $("#auth_s").val("");
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: 'Invalid token submitted, PIN must be numeric and not empty!!!'
        });

    }
}

function auth_edit(x) {
    var tp = $("#auth_" + x).val();
    if (tp !== "") {
        if (x === "a") {
            $("#auth_u").focus();
        } else if (x === "u") {
            $("#auth_t").focus();
        } else if (x === "t") {
            $("#auth_h").focus();
        } else if (x === "h") {
            $("#auth_s").focus();
        } else if (x === "s") {
            $("#auth_s").val($("#auth_s").val().slice(0, 1));
        }
    } else {
        $("#auth_a").val("");
        $("#auth_u").val("");
        $("#auth_t").val("");
        $("#auth_h").val("");
        $("#auth_s").val("");
        $("#auth_a").focus();
    }
}


function auth_focus(x) {
    var tp = $("#auth_" + x).val();
    var tpa = $("#auth_a").val();
    var tpu = $("#auth_u").val();
    var tpt = $("#auth_t").val();
    var tph = $("#auth_h").val();
    var tps = $("#auth_s").val();
    if (tp === "") {
        if (x === "a") {
            $("#auth_a").val("");
            $("#auth_u").val("");
            $("#auth_t").val("");
            $("#auth_h").val("");
            $("#auth_s").val("");
        } else if (x === "u") {
            if (tpa === "") {
                $("#auth_a").focus();
            }
            $("#auth_u").val("");
            $("#auth_t").val("");
            $("#auth_h").val("");
            $("#auth_s").val("");

        } else if (x === "t") {
            if (tpu === "") {
                $("#auth_u").focus();
            }
            $("#auth_t").val("");
            $("#auth_h").val("");
            $("#auth_s").val("");

        } else if (x === "h") {
            if (tpt === "") {
                $("#auth_t").focus();
            }
            $("#auth_h").val("");
            $("#auth_s").val("");

        } else if (x === "s") {
            if (tph === "") {
                $("#auth_h").focus();
            }
            $("#auth_s").val("");

        }
    } else {
        if (x === "a") {
            $("#auth_a").val("");
            $("#auth_u").val("");
            $("#auth_t").val("");
            $("#auth_h").val("");
            $("#auth_s").val("");
        } else if (x === "u") {
            $("#auth_u").val("");
            $("#auth_t").val("");
            $("#auth_h").val("");
            $("#auth_s").val("");
        } else if (x === "t") {
            $("#auth_t").val("");
            $("#auth_h").val("");
            $("#auth_s").val("");
        } else if (x === "h") {
            $("#auth_h").val("");
            $("#auth_s").val("");
        } else if (x === "s") {
            $("#auth_s").val("");
        }
    }
}

function toggle_history(a, b) {
    if (b === "open") {
        $("#toggle-" + a + "-history-bt").html('<i class="fa fa-chevron-up" style="margin-right: 5px;"></i> HISTORY');
        $("#" + a + "-history-cont").removeClass('hidden');
        $("#toggle-" + a + "-history-bt").attr("onclick", "toggle_history('" + a + "', 'close')");
    } else if (b === "close") {
        $("#toggle-" + a + "-history-bt").html('<i class="fa fa-chevron-down" style="margin-right: 5px;"></i> HISTORY');
        $("#" + a + "-history-cont").addClass('hidden');
        $("#toggle-" + a + "-history-bt").attr("onclick", "toggle_history('" + a + "', 'open')");
    }
}


function new_rider() {
    var state = $("#rider-new-state").val();
    var email = $("#rider-new-email").val();
    if (state !== "") {
        var sp = email.split("@");
        var spp = email.split(".");
        if (email !== "" && sp.length === 2 && spp.length >= 2) {
                    $("#rider-new-bt").html('<div class="lds-ellipsis-small"><div></div><div></div><div></div><div></div></div>');
                    $.post('riders/', {state: state, email: email}, function (data) {
                        $("#rider-new-bt").html('ADD <i class="fa fa-plus"></i>');
                        var resp = JSON.parse(data);
                        if (resp.done === true) {
                            Lobibox.notify('success', {
                                delay: false,
                                showClass: 'rollIn',
                                hideClass: 'rollOut',
                                msg: resp.mes
                            });
                            setTimeout(function () {
                                document.location.reload();
                            }, 3000);
                        } else {
                            Lobibox.notify('error', {
                                delay: false,
                                showClass: 'rollIn',
                                hideClass: 'rollOut',
                                msg: resp.mes
                            });
                        }
                    });
                
        } else {
            Lobibox.notify('error', {
                delay: false,
                showClass: 'rollIn',
                hideClass: 'rollOut',
                msg: 'Invalid email address!'
            });
        }
    } else {
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: 'State must be specified!'
        });
    }
}
function new_charges() {
    var state = $("#charges-new-state").val();
    var zone = $("#charges-new-zone").val();
    var pickup = $("#charges-new-pickup").val();
    var delivery = $("#charges-new-delivery").val();
    if (state !== "") {
        if (zone !== "") {
            if (pickup !== "" && parseInt(pickup) >= 0) {
                if (delivery !== "" && parseInt(delivery) >= 0) {
                    $("#charges-new-bt").html('<div class="lds-ellipsis-small"><div></div><div></div><div></div><div></div></div>');
                    $.post('charges/', {state: state, zone: zone, pickup: pickup, delivery: delivery}, function (data) {
                        $("#charges-new-bt").html('ADD <i class="fa fa-plus"></i>');
                        var resp = JSON.parse(data);
                        if (resp.done === true) {
                            Lobibox.notify('success', {
                                delay: false,
                                showClass: 'rollIn',
                                hideClass: 'rollOut',
                                msg: resp.mes
                            });
                            setTimeout(function () {
                                document.location.reload();
                            }, 3000);
                        } else {
                            Lobibox.notify('error', {
                                delay: false,
                                showClass: 'rollIn',
                                hideClass: 'rollOut',
                                msg: resp.mes
                            });
                        }
                    });
                } else {
                    Lobibox.notify('error', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: 'Delivery price must be numeric!'
                    });
                }
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: 'Pickup price must be numeric!'
                });
            }
        } else {
            Lobibox.notify('error', {
                delay: false,
                showClass: 'rollIn',
                hideClass: 'rollOut',
                msg: 'Zone name must be specified!'
            });
        }
    } else {
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: 'State must be specified!'
        });
    }
}


function save_charges(a) {
    var state = $("#charges-state" + a).val();
    var zone = $("#charges-zone" + a).val();
    var pickup = $("#charges-pickup" + a).val();
    var delivery = $("#charges-delivery" + a).val();
    if (state !== "") {
        if (zone !== "") {
            if (pickup !== "" && parseInt(pickup) >= 0) {
                if (delivery !== "" && parseInt(delivery) >= 0) {
                    $("#charges-save" + a).html('<div class="lds-ellipsis-small"><div></div><div></div><div></div><div></div></div>');
                    $.post('charges/edit/', {ref: a, state: state, zone: zone, pickup: pickup, delivery: delivery}, function (data) {
                        $("#charges-save" + a).html('<i class="fa fa-save"></i> SAVE EDIT');
                        var resp = JSON.parse(data);
                        if (resp.done === true) {
                            Lobibox.notify('success', {
                                delay: false,
                                showClass: 'rollIn',
                                hideClass: 'rollOut',
                                msg: resp.mes
                            });
                            setTimeout(function () {
                                document.location.reload();
                            }, 3000);
                        } else {
                            Lobibox.notify('error', {
                                delay: false,
                                showClass: 'rollIn',
                                hideClass: 'rollOut',
                                msg: resp.mes
                            });
                        }
                    });
                } else {
                    Lobibox.notify('error', {
                        delay: false,
                        showClass: 'rollIn',
                        hideClass: 'rollOut',
                        msg: 'Delivery price must be numeric!'
                    });
                }
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: 'Pickup price must be numeric!'
                });
            }
        } else {
            Lobibox.notify('error', {
                delay: false,
                showClass: 'rollIn',
                hideClass: 'rollOut',
                msg: 'Zone name must be specified!'
            });
        }
    } else {
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: 'State must be specified!'
        });
    }
}



function delete_charges(a) {
    var state = $("#charges-state" + a).val();
    if (a !== "" && state !== "") {
        $("#charges-delete" + a).html('<div class="lds-ellipsis-small"><div></div><div></div><div></div><div></div></div>');
        $.post('charges/del/', {ref: a, state: state}, function (data) {
            $("#charges-delete" + a).html('<i class="fa fa-save"></i> SAVE EDIT');
            var resp = JSON.parse(data);
            if (resp.done === true) {
                Lobibox.notify('success', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: resp.mes
                });
                setTimeout(function () {
                    document.location.reload();
                }, 3000);
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: resp.mes
                });
            }
        });

    } else {
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: 'Invalid request!!!'
        });
    }
}


function delete_rider(a, b) {
    if (a !== "" && b !== "") {
        $("#rider-delete" + b).html('<div class="lds-ellipsis-small"><div></div><div></div><div></div><div></div></div>');
        $.post('riders/del/', {ref: a}, function (data) {
            $("#rider-delete" + a).html('<i class="fa fa-trash"></i> DELETE');
            var resp = JSON.parse(data);
            if (resp.done === true) {
                Lobibox.notify('success', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: resp.mes
                });
                setTimeout(function () {
                    document.location.reload();
                }, 3000);
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: resp.mes
                });
            }
        });

    } else {
        Lobibox.notify('error', {
            delay: false,
            showClass: 'rollIn',
            hideClass: 'rollOut',
            msg: 'Invalid request!!!'
        });
    }
}


function assign_rider(a){
    if(a !== ""){
        var rider = $("#rider-"+a).val();
        $.post('riders/assign/', {rider:rider, ref:a}, function(data){
             var resp = JSON.parse(data);
            if (resp.done === true) {
                Lobibox.notify('success', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: resp.mes
                });
                setTimeout(function () {
                    document.location.reload();
                }, 3000);
            } else {
                Lobibox.notify('error', {
                    delay: false,
                    showClass: 'rollIn',
                    hideClass: 'rollOut',
                    msg: resp.mes
                });
            }
        });
    }
}