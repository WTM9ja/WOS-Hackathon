<?php

include '../configs.php';
require '../mailgun/vendor/autoload.php';

use Mailgun\Mailgun;

define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if (!IS_AJAX) {
    die('Restricted access');
}
$pos = strpos($_SERVER['HTTP_REFERER'], getenv('HTTP_HOST'));
if ($pos === false) {
    die('Restricted access');
}
if (isset($_POST['fname'], $_POST['lname'], $_POST['email'], $_POST['mobile'], $_POST['pass'], $_POST['conpass'], $_POST['rfr'])) {
    if (!empty($_POST['fname'] && $_POST['lname'] && $_POST['email'] && $_POST['mobile'] && $_POST['pass'] && $_POST['conpass'])) {
        if (preg_match('#^(([a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+\.?)*[a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+)@(([a-z0-9-_]+\.?)*[a-z0-9-_]+)\.[a-z]{2,}$#i', $_POST['email'])) { //validate email
            if ($_POST['pass'] == $_POST['conpass']) {
                $fname = htmlentities($_POST['fname']);
                $lname = htmlentities($_POST['lname']);
                $email = $_POST['email'];
                $mobile = htmlentities($_POST['mobile']);
                $pass = sha1($_POST['pass']);
                $r1 = mt_rand(10, 99);
                $r2 = time();
                $r3 = mt_rand(0, 25);
                $r4 = mt_rand(0, 9);
                $r5 = mt_rand(0, 25);
                $r6 = mt_rand(0, 25);
                $arr = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
                $unk = $r1 . $arr[$r6] . $r2 . $arr[$r3] . $r4 . $arr[$r5];
                $chk = $db->query('select id from users where email = "' . $email . '"');
                if ($chk->rowCount() == 0) {
                    $c1 = mt_rand(0, 9);
                    $c2 = mt_rand(0, 9);
                    $c3 = mt_rand(0, 9);
                    $c4 = mt_rand(0, 9);
                    $c5 = mt_rand(0, 9);
                    $code = $c1 . $c2 . $c3 . $c4 . $c5;
                    $rfr = "";
                    if(!empty($_POST['rfr'])){
                        $rfr = htmlentities($_POST['rfr']);
                    }
                    $ins = $db->prepare('insert into users (id, fname, lname, email, plug, password, mobile, unk, role, balance, verified, code, bank, accl, accname, premium, rfr, refbonus, dp, active, regdate) VALUES(:id, :fname, :lname, :email, :plug, :password, :mobile, :unk, :role, :balance, :verified, :code, :bank, :accl, :accname, :premium, :rfr, :refbonus, :dp, :active, :regdate)');
                    $do = $ins->execute(array(':id' => '0', ':fname' => $fname, ':lname' => $lname, ':email' => $email, ':plug' => $_POST['pass'], ':password' => $pass, ':mobile' => $mobile, ':unk' => $unk, ':role' => '', ':balance' => '0', ':verified' => '', ':code' => $code . "//" . (time() + 10 * 60), ":bank" => "", ":accl" => "", ":accname" => "", ":premium" => "", ":rfr" => $rfr, ":refbonus" => 0, ":dp" => "../img/avatar.png", ":active" => "", ':regdate' => time()));
                    if ($do) {
                        $_SESSION['email'] = $email;
//                        $mail = TRUE;
                        $mg = Mailgun::create('5701e01da91a5e2c77850d785e798e32-52cbfb43-57ddf63f');
                        $mail = $mg->messages()->send('mg.k-dev.org', [
                            'from' => 'WTM9ja <noreply@mg.k-dev.org>',
                            'to' => strtoupper($fname) . ' <' . $email . '>',
                            'subject' => 'WTM9ja (' . $code . ')',
                            'text' => "Dear " . strtoupper($fname . " " . $lname) . ", kindly use " . $code . " as your activation PIN on WTM9ja.\n\n"
                            . "\n"
                            . "\nBest Regards,\nWTM9ja Team."
                        ]);
                        if (!$mail) {
                            echo 'Oops! An error occured while sending email confirmation code!';
                        } else {
                            echo 'success';
                        }
                    } else {
                        echo "Oops! An error occured while trying to sign you up.";
                    }
                } else {
                    echo "Oops! An account already exist with this email address.";
                }
            } else {
                echo "Passwords do not match!";
            }
        } else {
            echo "Invalid email address.";
        }
    } else {
        echo "Oops! All fields are required.";
    }
}


if (isset($_POST['conf'])) {
    if (!empty($_POST['conf'])) {
        $code = $_POST['conf'];
        if (strlen($code) == 5) {
            $email = $_SESSION['email'];
            $st = $db->query('select code, verified from users where email = "' . $email . '"');
            if ($st->rowCount() == 1) {
                $dt = $st->fetchAll(PDO::FETCH_ASSOC)[0];
                if ($dt['verified'] == "") {
                    $co = explode("//", $dt['code']);
                    if ($code == $co[0]) {
                        if ($co[1] >= time()) {
                            $do = $db->query('update users set verified = "Y" where email = "' . $email . '"');
                            if ($do) {
                                echo "Account successfully activated.";
                                unset($_SESSION['email']);
                            } else {
                                echo "Oops! An error occured while trying to activate your account.";
                            }
                        } else {
                            echo "This code has expired, kindly click on <b>Resend Code</b> button to generate another activation code.";
                        }
                    } else {
                        echo "This code is invalid!";
                    }
                } else {
                    echo "This user's account has been verified before now!";
                }
            } else {
                echo "Unrecognised user!!!";
            }
        } else {
            echo "Inavlid activation code.";
        }
    } else {
        echo "Inavlid activation code.";
    }
}

if (isset($_POST['resend'])) {
    $email = $_SESSION['email'];
    $chk = $db->query('select * from users where email = "' . $email . '"');
    if ($chk->rowCount() == 1) {
        $c1 = mt_rand(0, 9);
        $c2 = mt_rand(0, 9);
        $c3 = mt_rand(0, 9);
        $c4 = mt_rand(0, 9);
        $c5 = mt_rand(0, 9);
        $code = $c1 . $c2 . $c3 . $c4 . $c5;
        $rw = $chk->fetchAll(PDO::FETCH_ASSOC)[0];
        $do = $db->query('update users set code = "' . $code . "//" . (time() + 10 * 60) . '" where email = "' . $email . '"');
        if ($do) {
//            $mail = TRUE;
            $mg = Mailgun::create('5701e01da91a5e2c77850d785e798e32-52cbfb43-57ddf63f');
            $mail = $mg->messages()->send('mg.k-dev.org', [
                'from' => 'WTM9ja <noreply@mg.k-dev.org>',
                'to' => strtoupper($rw['fname']) . ' <' . $email . '>',
                'subject' => 'WTM9ja (' . $code . ')',
                'text' => "Dear " . strtoupper($rw['fname'] . " " . $rw['lname']) . ", kindly use " . $code . " as your activation PIN on WTM9ja.\n\n"
                . "\n"
                . "\nBest Regards,\nWTM9ja Team."
            ]);
            if (!$mail) {
                echo 'An error occured while resending confirmation mail!';
            } else {
                echo "A new code has been sent";
            }
        } else {
            echo "Oops! An error occured while trying to generate a new activation code for you.";
        }
    } else {
        echo "Unrecognised user credentials!";
    }
}