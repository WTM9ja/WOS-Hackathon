<?php
//logout
include '../configs.php';
unset($_SESSION['coin']);
@session_destroy();
header('location: ../');
