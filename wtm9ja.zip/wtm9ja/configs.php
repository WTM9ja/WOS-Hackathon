<?php
@session_start();
$db = new PDO('mysql:host=localhost;dbname=wtm9ja;charset=utf8mb4', 'root', '');