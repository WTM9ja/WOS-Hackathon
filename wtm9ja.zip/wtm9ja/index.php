<?php 
include 'configs.php';
?>
<!doctype html>
<html class="no-js" lang="zxx">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>WTM9ja Chat Bot</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="manifest" href="site.webmanifest">
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">

        <!-- CSS here -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/slicknav.css">
        <link rel="stylesheet" href="assets/css/flaticon.css">
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <link rel="stylesheet" href="assets/css/magnific-popup.css">
        <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
        <link rel="stylesheet" href="assets/css/themify-icons.css">
        <link rel="stylesheet" href="assets/css/slick.css">
        <link rel="stylesheet" href="assets/css/nice-select.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="css/notifications/Lobibox.min.css">
        <link rel="stylesheet" href="css/notifications/notifications.css" >
        <link rel="stylesheet" href="css/css.css" >
        <style>
            .hidden {
                display: none !important;
            }
            
            @media (max-width: 974px){
                #mobile-quote-bt{
                    display: block !important;
                }
            }
            @media (min-width: 975px){
                #mobile-quote-bt{
                    display: none !important;
                }
            }
        </style>
        
    </head>
    <body>
        <!--? Preloader Start -->
        <div id="preloader-active">
            <div class="preloader d-flex align-items-center justify-content-center">
                <div class="preloader-inner position-relative">
                    <div class="preloader-circle"></div>
                    <div class="preloader-img pere-text">
                        <img src="assets/img/favicon.png" alt="" style="width: 60px; height: 60px; border-radius: 50%;">
                    </div>
                </div>
            </div>
        </div>
        <!-- Preloader Start -->
        <header>
            <!-- Header Start -->
            <div class="header-area" style="border-width: 0px;">
                <div class="main-header ">
                    
                    <div class="header-bottom  header-sticky" style="border-top-width: 0px;">
                        <div class="container">
                            <div class="row align-items-center">
                                <!-- Logo -->
                                <div class="col-xl-2 col-lg-2">
                                    <div class="logo">
                                        <a href="#"><img src="assets/img/favicon.png" alt="" style="width: 60px; height: 60px; border-radius: 50%;"></a>
                                    </div>
                                </div>
                                <div class="col-xl-10 col-lg-10">
                                    <div class="menu-wrapper  d-flex align-items-center justify-content-end">
                                        <!-- Main-menu -->
                                        <div class="main-menu d-none d-lg-block">
                                            <nav> 
                                                <ul id="navigation">                                        
                                                    <li><a href="#" onclick="$('#login-modal').modal('show');"><i class="fa fa-lock"></i> Login</a></li>
                                                </ul>
                                            </nav>
                                        </div>
                                        <!-- Header-btn -->
                                        <div class="header-right-btn d-none d-lg-block ml-20" style="text-align: center;">
                                            <a href="script: void()" onclick="$('#reg-modal').modal('show');" class="btn header-btn" style="font-weight: bold;">SIGN UP</a>
                                        </div>
                                    </div>
                                </div> 
                                <!-- Mobile Menu -->
                                <div class="col-12">
                                    <div class="mobile_menu d-block d-lg-none"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Header End -->
        </header>
        



        <!-- Modal -->
        <div class="modal fade" id="login-modal" role="dialog">
            <div class="modal-dialog modal-md">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" style="text-transform: uppercase;"><i class="fa fa-lock"></i> LOGIN</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div style="min-height: 200px; width: 100%;">
                            <div class="form-group">
                                <label for="login-email" style='font-weight: bold; font-family: "Teko",sans-serif; color: #067bba; margin-top: 0px; font-style: normal;'>Email</label>
                                <input id="login-email" type="text" placeholder="Email Address" class="form-control" />
                            </div>
                            <div class="form-group">
                                <label for="login-pass" style='font-weight: bold; font-family: "Teko",sans-serif; color: #067bba; margin-top: 0px; font-style: normal;'>Password</label>
                                <div style="width: 100%; border: 1px solid #ced4da; border-radius: 0.25rem;">
                                    <input id="login-pass" type="password" placeholder="Password" class="form-control" style="display: inline; border: 0px solid #ced4da; width: 90%;" />
                                    <span id="show-pass" onclick="show_pass('show')" class="fa fa-eye" style="display: inline; margin-left: 10px; color: #067bba;"></span>
                                </div>
                            </div>
                            <div class="form-group" style="text-align: center;">
                                <span id="login-bt" class="btn" style="min-width: 150px;" onclick="login()">LOGIN <i class="fa fa-chevron-right"></i></span>
                                <br><br>
                                <p class="middle-text btn btn-primary" style="background: #067bba;" data-toggle="modal" data-target="#forgot-modal" onclick="$('#login-modal').modal('hide');">Forgot password?</p>
                                <p class="text-center text-muted">Not registered yet?</p>
                                <p class="btn btn-block" style="background: #067bba;" data-toggle="modal" data-target="#reg-modal" onclick="$('#login-modal').modal('hide');"><strong>Sign Up Here!</strong></p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>




        <div class="modal fade" id="forgot-modal" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
            <div class="modal-dialog modal-md">

                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="Login" style="text-transform: uppercase;"><i class="fa fa-lock"></i> Forgot Password</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <form action="" method="post">
                            <div class="form-group">
                                <input type="text" class="form-control" id="email" placeholder="Enter email">
                            </div>
                        </form>
                        <p class="text-center">
                            <button class="btn btn-template-main"><i class="fa fa-check"></i> Submit</button>
                        </p>
                        <p class="text-center text-muted"><a class="btn btn-template-main btn-block" style="background: #067bba;" href="#" data-toggle="modal" data-target="#login-modal" onclick="$('#forgot-modal').modal('hide');" ><strong><i class="fa fa-chevron-left"></i> Back to login</strong></a></p>


                    </div>
                </div>
            </div>
        </div>



        <div class="modal fade" id="reg-modal" tabindex="-1" role="dialog" aria-labelledby="Sign Up" aria-hidden="true">
            <div class="modal-dialog modal-md">

                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="reg_head" style="text-transform: uppercase;"><i class="fa fa-user-plus"></i> Sign Up</h4>
                        <h4 class="modal-title hidden" id="conf_head" style="text-transform: uppercase;"><i class="fa fa-check-circle"></i> Activate Account</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div id="reg_form">
                            <form>
                                <div class="form-group col-md-12">
                                    <!--<label>First Name:</label>-->
                                    <input type="text" class="form-control" id="reg_fname" placeholder="Firstname">
                                </div>
                                <div class="form-group col-md-12">
                                    <!--<label>Last Name:</label>-->
                                    <input type="text" class="form-control" id="reg_lname" placeholder="Lastname">
                                </div>
                                <div class="form-group col-md-12">
                                    <!--<label>Email:</label>-->
                                    <input type="email" class="form-control" id="reg_email" placeholder="Email">
                                </div>
                                <div class="form-group col-md-12">
                                    <!--<label>Mobile:</label>-->
                                    <input type="text" class="form-control" id="reg_mobile" placeholder="Mobile (E.g 08012345678)">
                                </div>
                                <div class="form-group col-md-12">
                                    <!--<label>Password:</label>-->
                                    <input type="password" class="form-control" id="reg_pass" placeholder="Password">
                                </div>
                                <div class="form-group col-md-12">
                                    <!--<label>Confirm Password:</label>-->
                                    <input type="password" class="form-control" id="reg_conpass" placeholder="Confirm Password">
                                </div>
                                <div hidden class="form-group col-md-12">
                                    <!--<label>Referred By:</label>-->
                                    <input type="text" class="form-control" id="reg_rfr" placeholder="Referred by (E.g 08012345678)">
                                </div>

                            </form>
                            <p class="text-center">
                                <button onclick="reg()" id="reg_bt" class="btn btn-template-main" style="min-width: 60px;"><i class="fa fa-plus"></i><i class="fa fa-user"></i> Submit</button>
                            </p>

                            <p class="text-center text-muted">Already a user?</p>
                            <p class="text-center text-muted btn btn-template-main btn-block" data-toggle="modal" data-target="#login-modal" style="background: #067bba;" onclick="$('#reg-modal').modal('hide');" ><strong style="color: #fff;">Login</strong></p>
                        </div>
                        <div id="conf" class="hidden">
                            <form>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="conf_code" placeholder="Enter code">
                                </div>  
                            </form>
                            <p class="text-center">
                                <button onclick="confm()" class="btn btn-template-main" id="conf_bt"><i class="fa fa-check"></i> Confirm</button>
                            </p>
                            <p class="text-center text-muted btn btn-template-main btn-block" onclick="resend()" style="background: #067bba;" id="resend_bt"><strong>Resend code</strong></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <!-- JS here -->

        <script src="./assets/js/vendor/modernizr-3.5.0.min.js"></script>
        <!-- Jquery, Popper, Bootstrap -->
        <script src="js/jquery-1.11.2.min.js"></script>
        <script src="./assets/js/vendor/jquery-1.12.4.min.js"></script>
        <script src="js/notifications/Lobibox.js"></script>
        <script src="js/notifications/notification-active.js"></script>
        <script src="js/js.js"></script>
        
        <script src="./assets/js/popper.min.js"></script>
        <script src="./assets/js/bootstrap.min.js"></script>
        <!-- Jquery Mobile Menu -->
        <script src="./assets/js/jquery.slicknav.min.js"></script>

        <!-- Jquery Slick , Owl-Carousel Plugins -->
        <script src="./assets/js/owl.carousel.min.js"></script>
        <script src="./assets/js/slick.min.js"></script>
        <!-- One Page, Animated-HeadLin -->
        <script src="./assets/js/wow.min.js"></script>
        <script src="./assets/js/animated.headline.js"></script>
        <script src="./assets/js/jquery.magnific-popup.js"></script>

        <!-- Nice-select, sticky -->
        <script src="./assets/js/jquery.nice-select.min.js"></script>
        <script src="./assets/js/jquery.sticky.js"></script>

        <!-- contact js -->
        <script src="./assets/js/contact.js"></script>
        <script src="./assets/js/jquery.form.js"></script>
        <script src="./assets/js/jquery.validate.min.js"></script>
        <script src="./assets/js/mail-script.js"></script>
        <script src="./assets/js/jquery.ajaxchimp.min.js"></script>

        <!-- Jquery Plugins, main Jquery -->	
        <script src="./assets/js/plugins.js"></script>
        <script src="./assets/js/main.js"></script>
        
    </body>
</html>