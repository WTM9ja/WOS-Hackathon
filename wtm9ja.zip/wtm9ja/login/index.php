<?php

include '../configs.php';
require '../mailgun/vendor/autoload.php';

use Mailgun\Mailgun;

define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if (!IS_AJAX) {
    die('Restricted access');
}
$pos = strpos($_SERVER['HTTP_REFERER'], getenv('HTTP_HOST'));
if ($pos === false) {
    die('Restricted access');
}

if (isset($_POST['email'], $_POST['pass'])) {
    if (!empty($_POST['email'] && $_POST['pass'])) {
        $email = $_POST['email'];
        $pass = sha1($_POST['pass']);
        $chk = $db->query('select * from users where email = "' . $email . '"');
        if ($chk->rowCount() == 1) {
            $rw = $chk->fetchAll(PDO::FETCH_ASSOC)[0];
            if ($pass == $rw['password']) {
                if ($rw['verified'] == "Y") {
                    $_SESSION['coin'] = $rw['unk'];
                    echo "success";
                } else {
                    if ($rw['verified'] == "") {
                        $_SESSION['email'] = $email;
                        $c1 = mt_rand(0, 9);
                        $c2 = mt_rand(0, 9);
                        $c3 = mt_rand(0, 9);
                        $c4 = mt_rand(0, 9);
                        $c5 = mt_rand(0, 9);
                        $code = $c1 . $c2 . $c3 . $c4 . $c5;
//                    $mail = TRUE;
                        $mg = Mailgun::create('5701e01da91a5e2c77850d785e798e32-52cbfb43-57ddf63f');
                        $mail = $mg->messages()->send('mg.k-dev.org', [
                            'from' => 'WTM9ja <noreply@mg.k-dev.org>',
                            'to' => strtoupper($rw['fname']) . ' <' . $email . '>',
                            'subject' => 'WTM9ja (' . $code . ')',
                            'text' => "Dear " . strtoupper($rw['fname'] . " " . $rw['lname']) . ", kindly use " . $code . " as your activation PIN on WTM9ja.\n\n"
                            . "\n"
                            . "\nBest Regards,\nWTM9ja Team."
                        ]);

                        if (!$mail) {
                            echo 'An error occured while sending confirmation email, try again.';
                        } else {
                            echo "Oops! This user's account is not verified.";
                        }
                    } else {
                        echo "You account has been blocked, contact the admin to unblock your account!";
                    }
                }
            } else {
                echo "Username or Password is incorrect.";
            }
        } else {
            echo "This user does not exist on this system.";
        }
    } else {
        echo "Email and password are required.";
    }
}